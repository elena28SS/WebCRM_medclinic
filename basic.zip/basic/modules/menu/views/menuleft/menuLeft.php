<?php
<div class="menu-left-index">
echo Menu::widget([
    'items' => [ "Иванов Иван Ильич. Кардиолог","Агафонова Светлана Юрьевна.Хирург","Потапов Алексей Иванович.УЗИ врач",
        "Степанченко Елена Алексеевна.Уролог","Чернышков Андрей Викторович","Tокомада Инна Сергеевна.Гастроэнтеролог","Кобейн Ильдар Гаясович.Терапевт"]
       
        ['label' => 'Иванов Иван Ильич. Кардиолог', 'url' => ['site/1233']],
        // 'Products' menu item will be selected as long as the route is 'product/index'
        ['label' => 'Агафонова Светлана Юрьевна.Хирург', 'url' => ['site/12133']], 
      ['label' => 'Потапов Алексей Иванович.УЗИ врач', 'url' => ['site/21145']], 
     ['label' => 'Степанченко Елена Алексеевна.Уролог', 'url' => ['site/22133']], 
     ['label' => 'Чернышков Андрей Викторович. Терапевт', 'url' => ['site/221145']], 
     ['label' => 'Tокомада Инна Сергеевнa Гастроэнтеролог', 'url' => ['site/234353']],
    ['label' => 'Кобейн Ильдар Гаясович	Терапевт', 'url' => ['site/455860']], 
            //'items' => [
            //['label' => 'New Arrivals', 'url' => ['product/index', 'tag' => 'new']],
           // ['label' => 'Most Popular', 'url' => ['product/index', 'tag' => 'popular']],/*
        
        ['label' => 'Login', 'url' => ['site/login'], 'visible' => Yii::$app->user->isGuest]],
    
]);