<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\PriceLabObsl */

$this->title = Yii::t('app', 'Create Price Lab Obsl');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Price Lab Obsls'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="price-lab-obsl-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
