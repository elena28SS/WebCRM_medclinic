<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\PriceLabObsl */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="price-lab-obsl-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'id_analisa')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'ed_iz')->textInput() ?>

    <?= $form->field($model, 'Stoimost')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'valuta')->textarea(['rows' => 6]) ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
