<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\PriceLabObsl */

$this->title = $model->id_analisa;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Price Lab Obsls'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="price-lab-obsl-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a(Yii::t('app', 'Update'), ['update', 'id' => $model->id_analisa], ['class' => 'btn btn-primary']) ?>
        <?= Html::a(Yii::t('app', 'Delete'), ['delete', 'id' => $model->id_analisa], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => Yii::t('app', 'Are you sure you want to delete this item?'),
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id_analisa',
            'ed_iz',
            'Stoimost',
            'valuta:ntext',
        ],
    ]) ?>

</div>
