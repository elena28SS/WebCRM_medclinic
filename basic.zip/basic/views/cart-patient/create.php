<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\CartPatient */

$this->title = 'Create Cart Patient';
$this->params['breadcrumbs'][] = ['label' => 'Cart Patients', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="cart-patient-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
