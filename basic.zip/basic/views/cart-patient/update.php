<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\CartPatient */

$this->title = 'Update Cart Patient: ' . $model->id_patient;
$this->params['breadcrumbs'][] = ['label' => 'Cart Patients', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id_patient, 'url' => ['view', 'id' => $model->id_patient]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="cart-patient-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
