<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\CartPatientSearch */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="cart-patient-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <?= $form->field($model, 'id_patient') ?>

    <?= $form->field($model, 'id_sotr') ?>

    <?= $form->field($model, 'Complains') ?>

    <?= $form->field($model, 'Lecheniye') ?>

    <?= $form->field($model, 'Anamnesis_morbi') ?>

    <?php // echo $form->field($model, 'Anamnesis_vitae') ?>

    <?php // echo $form->field($model, 'Lek_allergye') ?>

    <?php // echo $form->field($model, 'kod_Mkb10') ?>

    <?php // echo $form->field($model, 'Name_Diagnozis') ?>

    <?php // echo $form->field($model, 'Epicrysis') ?>

    <div class="form-group">
        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton('Reset', ['class' => 'btn btn-default']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
