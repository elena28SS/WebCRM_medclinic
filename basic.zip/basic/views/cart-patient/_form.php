<?php
use yii\helpers\ArrayHelper;
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use app\models\InfoPatients;
use app\models\Sotrudniki

/* @var $this yii\web\View */
/* @var $model app\models\CartPatient */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="cart-patient-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'id_patient')->textInput() ?>

    <?= $form->field($model, 'id_sotr')-> dropDownList(ArrayHelper::map(Sotrudniki::find()->select(['FIO','id_sotr'])->orderBy('id_sotr')->all(),'id_sotr','FIO'),['prompt'=>''])?>

    <?= $form->field($model, 'Complains')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'Lecheniye')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'Anamnesis_morbi')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'Anamnesis_vitae')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'Lek_allergye')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'kod_Mkb10')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'Name_Diagnozis')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'Epicrysis')->textarea(['rows' => 6]) ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
