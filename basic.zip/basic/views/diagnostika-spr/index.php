<?php
use app\models\TypeDiagnostika;
use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $searchModel app\models\DiagnostikaSprSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Справочник диагностики';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="diagnostika-spr-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Создать новую запись', ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            //['class' => 'yii\grid\SerialColumn'],

             [
            'attribute'=>'id',
            'label'=>'Категория диагностики',
            'format'=>'text', // Возможные варианты: raw, html
             'content'=>function($data){
              
             return $data->getTypeDiagnostikaName();
         },
             'filter' => \app\models\TypeDiagnostika::getListdropdown(),
   
             ],
            'id',
            'name_diagnjstik:ntext',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
