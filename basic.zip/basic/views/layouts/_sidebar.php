   
 
	
            
<ul class="nav nav-pills nav-stacked ">
             
            
            <li class="active "><a href="http://step.yii/tablzapisinapriem ">Запись на прием</a></li> 
            <li class="active "><a href="http://step.yii/setka-priema ">Сетка приема</a></li> 
            <li class="active "><a href="http://step.yii/raspisanie ">Расписание</a></li>
            

                
</ul>
       
 

