

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

		        
			<ul class="nav nav-pills nav-stacked ">
            <li><a href="http://step.yii/sotrudn/view?id=1213 "></a></li>
            <li class="active "><a href="">Мои пациенты<span class="sr-only ">(current)</span></a></li>
            <li class="active "><a href="">Мои приемы<span class="sr-only ">(current)</span></a></li>
            <li class="active "><a href="">Расписание<span class="sr-only ">(current)</span></a></li>
            <li class="active "><a href="">*<span class="sr-only ">(current)</span></a></li>
            <li class="active "><a href="">*</a></li>
            <li class="active "><a href="">Клинические обследования</a></li>
            <li class="active "><a href=" ">Специалисты</a></li>
            
</ul>

    