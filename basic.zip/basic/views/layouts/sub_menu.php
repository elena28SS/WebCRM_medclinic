

    <?= yii\widgets\Menu::widget([
'items' => [
['label' => 'Хирург', 'url' => ['sotrudn/view?id=12133']],
['label' => 'Кардиолог', 'url' => ['/sotrudn/view?id=1233']],
['label' => 'УЗИ', 'url' => ['sotrudn/view?id=12133'], 'items' => [
['label' => 'Терапевты', 'url' => ['product/index', 'tag' => 'new']],
['label' => 'Most Popular', 'url' => ['product/index', 'tag' => 'popular']],
]],
'options' => [
					'class' => 'navbar-nav nav nav-pills nav-stacked',
					'id'=>'navbar-id',
					'style'=>'font-size: 14px;',
					'data-tag'=>'yii2-menu',
				],
], 
        ]) ?>
         
/* To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
       

