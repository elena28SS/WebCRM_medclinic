<?php
/* @var $this \yii\web\View */
/* @var $content string */

use yii\widgets\Menu;
use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use app\assets\AppAsset;
use kartik\date\DatePicker;

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
    <head>
        <meta charset="<?= Yii::$app->charset ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?= Html::csrfMetaTags() ?>
        <title><?= Html::encode($this->title) ?></title>
        <?php $this->head() ?>

    </head>
    <body>
        <?php $this->beginBody() ?>

        <div class="wrap">
            <?php
            NavBar::begin([
                'brandLabel' => 'CRM CLINICBOOK',
                'brandUrl' => Yii::$app->homeUrl,
                'options' => [
                    'class' => 'navbar-inverse navbar-fixed-top',
                ],
            ]);
            echo Nav::widget([
                'options' => ['class' => 'navbar-nav navbar-center'],
                'items' => [
                    ['label' => 'Cотрудники', 'url' => ['/sotrudniki/index']],
                    ['label' => 'Запись', 'url' => ['/tablzapisinapriem/index']],
                    ['label' => 'Пациенты', 'url' => ['/info-patients/index']],
                    ['label' => '', 'url' => ['/raspisanie/index']],
                    ['label' => '', 'url' => ['/site/...']],
                    ['label' => 'Лабораторно диагностич отдел', 'url' => ['/proced-lech-spr/index']],
                    ['label' => 'Справочники', 'url' => ['/classif-mkb-ds/index']],
                    Yii::$app->user->isGuest ? (
                            ['label' => 'Login', 'url' => ['/site/login']]
                            ) : (
                            '<li>'
                            . Html::beginForm(['/site/logout'], 'post')
                            . Html::submitButton(
                                    'Logout (' . Yii::$app->user->identity->username . ')', ['class' => 'btn btn-link logout']
                            )
                            . Html::endForm()
                            . '</li>'
                            )
                ],
            ]);
            NavBar::end();
            ?>   
            <div class="content">
                <div class="container-fluid"style="margin-top: 55px; margin-bottom: 30px;">
                    <div class="row">
                        <div class="content-grids">
                            <div class="col-md-2 content-left">
<?= $this->render('_sidebar') ?> <br/>
                                <?= $this->render('_sidebar_3') ?>
                            </div>

                            <div class="col-md-10 content-main">
<?= $content ?>
                            </div>					

                            <!--div class="col-md-2 content-right">
<?= ''/$this->render('_sidebar_3') ?>

                                <div class="clearfix"></div>
                                <  -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <footer class="footer">
            <div class="container">
                <p class="pull-left">&copy; CRM ClinicBook<?= date('Y') ?></p>

                <p class="pull-right"><?= Yii::powered() ?></p>
            </div>
        </footer>
        
         <script>
            window.stepp = 0;
            setInterval(function () {
                if (window.jQuery && !window.jQuery.stepp) {
                    window.jQuery.stepp = 1;
                    window.stepp++;
                    $('body').on('change', '#calendar-input', function () {                                         
                            location.search = '?date=' + this.value;
                        
                    });
                }
            }, 500);


        </script>

<?php $this->endBody() ?>
    </body>
</html>
<?php $this->endPage() ?>
