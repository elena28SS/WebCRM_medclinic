
<?php
use kartik\date\DatePicker;
?>
 <div class="well well-sm" style="background-color: #fff; width:235px">
		 <?=                 DatePicker::widget([
                            'name' => 'dp_5',
                            'type' => DatePicker::TYPE_INLINE,
                            'value' => Yii::$app->session->get('sys_date'),
                            'pluginOptions' => [
                                'format' => 'dd-m-yyyy'
                            ],
                            'options' => [
                                'id' => 'calendar-input'
                            ]
                        ]) ?>
	</div>					
						
 <div class="clearfix"></div>

