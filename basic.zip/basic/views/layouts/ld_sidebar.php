 <div class="sidebar-offcanvas
      "style="margin-top: 25px">
		        
			<ul class="nav nav-pills nav-stacked ">
            
             <li class="active "><a href="http://step.yii/proced-lech-spr ">Лечебн.процедуры<span class="sr-only ">(current)</span></a></li>
            <li class="active "><a href="http://step.yii/lab-analises"> Лабораторные анализы</a></li>
             <li class="active "><a href="http://step.yii/typelab-analises ">Категории лаборат.обсл</a></li>
            <li class="active "><a href="http://step.yii/type-diagnostika ">Категории диагностики</a></li>
            <li class="active "><a href="http://step.yii/type-proc-lech ">Категории лечеб.процедур</a></li>
              <li class="active "><a href="http://step.yii/diagnostika-spr ">/Методы диагностики/<span class="sr-only ">(current)</span></a></li>
</ul>

 <div class="clearfix"></div>
<div class="" style="margin-top: 15px">
<?php
use kartik\date\DatePicker;
?>
 <div class="well well-sm" style="background-color: #fff; width:219px">
		 <?=                 DatePicker::widget([
                            'name' => 'dp_5',
                            'type' => DatePicker::TYPE_INLINE,
                            'value' => Yii::$app->session->get('sys_date'),
                            'pluginOptions' => [
                                'format' => 'dd-m-yyyy'
                            ],
                            'options' => [
                                'id' => 'calendar-input'
                            ]
                        ]) ?>
	</div>
 </div>
</div>
						


    