<?
class MenuWidjet extends Widjet{
public function run()
{
 return '<h2>Hallo!</h2>'
}

}