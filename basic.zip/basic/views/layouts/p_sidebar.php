
		        
			<ul class="nav nav-pills nav-stacked ">
            <li><a href="http://step.yii/sotrudn/view?id=1213 "></a></li>
            <li class="active "><a href="http://step.yii/info-patients">Инфо пациента<span class="sr-only ">(current)</span></a></li>
            <li class="active "><a href="http://step.yii/cart-patient">Карта пациента<span class="sr-only ">(current)</span></a></li>
            <li class="active "><a href="http://step.yii/list-osmotr-phisic">Осмотр<span class="sr-only ">(current)</span></a></li>
            <li class="active "><a href="http://step.yii/list-diagnost-obsl">Диагностика<span class="sr-only ">(current)</span></a></li>
            <li class="active "><a href="http://step.yii/list-lab-obsledov" >Обследование</a></li>
            <li class="active "><a href="http://step.yii/list-lech-proced">Лечение</a></li>
            <li class="active "><a href=""></a></li>
            
</ul>

    