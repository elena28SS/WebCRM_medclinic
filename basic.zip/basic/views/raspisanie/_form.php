<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
/* @var $this yii\web\View */
/* @var $model app\models\Raspisanie */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="raspisanie-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'id')->textInput() ?>

    <?= $form->field($model, 'id_spec')->textInput() ?>

    <?= $form->field($model, 'id_sotr')-> dropDownList(ArrayHelper::map(app\models\Sotrudniki::find()->select(['FIO','id_sotr'])->orderBy('id_sotr')->all(),'id_sotr','FIO'),['prompt'=>'']) ?>

    <?= $form->field($model, 'Den_nedeli')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'Priem_begin')->textInput() ?>

    <?= $form->field($model, 'Priem_end')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
