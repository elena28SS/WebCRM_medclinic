<?php
use yii\helpers\ArrayHelper;
use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\RaspisanieSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Расписание';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="raspisanie-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Создать расписание', ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            //['class' => 'yii\grid\SerialColumn'],

            'id',
            [
            'attribute'=>'id_spec',
            'label'=>'Cпециальность',
            'format'=>'text', // Возможные варианты: raw, html
             'content'=>function($data){
             
             return $data->getSpecialisationSprName();
         },
             'filter' => app\models\SpecialisationSpr::getListdropdown(),
   
             ],   
             [
            'attribute'=>'id_sotr',
            'label'=>'ФИО врача',
            'format'=>'text', // Возможные варианты: raw, html
             'content'=>function($data){
              
             return $data->getSotrudnikiName();
         },
             'filter' => app\models\Sotrudniki::getListdropdown(),
   
             ],
            'Den_nedeli:ntext',
            'Priem_begin',
             'Priem_end',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
