<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\RaspisanieSearch */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="raspisanie-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <?= $form->field($model, 'id') ?>

    <?= $form->field($model, 'id_spec') ?>

    <?= $form->field($model, 'id_sotr') ?>

    <?= $form->field($model, 'Den_nedeli') ?>

    <?= $form->field($model, 'Priem_begin') ?>

    <?php // echo $form->field($model, 'Priem_end') ?>

    <div class="form-group">
        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton('Reset', ['class' => 'btn btn-default']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
