<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\DiagnosisMKB10 */

$this->title = Yii::t('app', 'Update {modelClass}: ', [
    'modelClass' => 'Diagnosis Mkb10',
]) . $model->kod MKB10;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Diagnosis Mkb10s'), 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->kod MKB10, 'url' => ['view', 'id' => $model->kod MKB10]];
$this->params['breadcrumbs'][] = Yii::t('app', 'Update');
?>
<div class="diagnosis-mkb10-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
