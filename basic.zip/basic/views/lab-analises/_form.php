<?php
use yii\helpers\ArrayHelper;
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use app\models\TypeLabAnalises;


/* @var $this yii\web\View */
/* @var $model app\models\LabAnalises */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="lab-analises-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'name_analisa')->textarea(['rows' => 1]) ?>

    <?= $form->field($model, 'id_type_analises')-> dropDownList(ArrayHelper::map(TypeLabAnalises::find()->select(['name_type_analises','id'])->orderBy('id')->all(),'id','name_type_analises'),['prompt'=>''])?>
 
                                      

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
