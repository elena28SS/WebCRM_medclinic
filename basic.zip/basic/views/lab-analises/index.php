<?php
use yii\helpers\ArrayHelper;
use app\models\TypeLabAnalises;
use yii\helpers\Html;
use yii\grid\GridView;


/* @var $this yii\web\View */
/* @var $searchModel app\models\LabAnalisesSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Лабораторные анализы');
$this->params['breadcrumbs'][] = $this->title;
?>
<div  <div class="lab-analises-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a(Yii::t('app', 'Создать лаб анализ'), ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
           // ['class' => 'yii\grid\SerialColumn'],            
             [
            'attribute'=>'id_type_diagnjstiki',
            'label'=>'Категория анализа',
            'format'=>'text', // Возможные варианты: raw, html
             'content'=>function($data){
              
             return $data->getTypeLabAnalisesName();
         },
             'filter' => TypeLabAnalises::getListdropdown(),
   
             ],
                            
            'name_analisa:ntext',
            'id_type_analises:integer',
            
                                       

            ['class' => 'yii\grid\ActionColumn'],
           ],
    ]);  ?>
           
    </div>
