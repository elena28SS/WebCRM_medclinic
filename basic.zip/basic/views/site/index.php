<?php

/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>ClinicBook  </h1>
		     <p class="lead"> Ваш лучший  органайзер!</p>
			 <?=\app\components\HalWidget::widget() ?>

        <p><a class="btn btn-lg btn-info" href="http://step.yii/site/login">Начните работать  с ClinicBook!</a></p>
    </div>

    <div class="body-content">

        <div class="row">
            <div class="col-lg-4">
                <h2>Раписания записи на прием в онлайн режиме!</h2>

                <p>Теперь все расписания  под рукой.  Вам  нужно только зайти на страницу  специалиста  выбрать время  и  записать  свои  данные .</p>

                <p><a class="btn btn-default" href="http://step.yii/tablzapisinapriem/index">ЗАПИСЬ НА ПРИЕМ &raquo;</a></p>
            </div>
            <div class="col-lg-4">
                <h2>Для  Специалистов </h2>

                <p>  Есть  свой  личный кабинет из которого  можно регистрировать пациента,  писать назначения в  его  электронной  карте,  вести  историю болезни  и лечения, записывать на процедуры.</p>

                <p><a class="btn btn-default" href="http://step.yii/info-patients">ИНФОКАРТА ПАЦИЕНТА;</a></p>
            </div>
            <div class="col-lg-4">
                <h2>Электронная Карта пациента</h2>

                <p>Позволяет наблюдать пациента  в динамическом  режиме,  вести документацию  и отчеты</p>

                <p><a class="btn btn-default" href="">КАРТА ИСТОРИИ БОЛЕЗНИ;</a></p>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-6">
                <h2>Справочники для специалистов и администратора</h2>

                <p>Справочник МКБ10,КомпанииТФОМС, полисы - все должно быть под рукойу главврача!</p>

                <p><a class="btn btn-default" href="http://step.yii/classif-mkb-ds/index">СПРАВОЧНИКИ &raquo;</a></p>
            </div>
            <div class="col-lg-6">
                <h2>Лабораторно-диагностическая панель </h2>

                <p> Справочник, с классификацией лабораторных анализов, аппаратной диагностики и лечебных процедур. заполнятся админом для  автоматической  вставки в листы назначений!</p>

                <p><a class="btn btn-default" href="http://step.yii/lab-analises">ЛДО</a></p>
            </div>
            
        </div>

    </div>
</div>
