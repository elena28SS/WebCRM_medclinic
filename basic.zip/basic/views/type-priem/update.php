<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\TypePriem */

$this->title = Yii::t('app', 'Update {modelClass}: ', [
    'modelClass' => 'Type Priem',
]) . $model->id_type_priem;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Type Priems'), 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id_type_priem, 'url' => ['view', 'id' => $model->id_type_priem]];
$this->params['breadcrumbs'][] = Yii::t('app', 'Update');
?>
<div class="type-priem-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
