<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\SetkaPriemaSearch */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="setka-priema-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <?= $form->field($model, 'id') ?>

    <?= $form->field($model, 'Data_priema') ?>

    <?= $form->field($model, 'id_specialn') ?>

    <?= $form->field($model, 'id_sotrudnika') ?>

    <?= $form->field($model, 'Den_nedeli') ?>

    <?php // echo $form->field($model, 'Time_priem_1') ?>

    <?php // echo $form->field($model, 'Time_priem_2') ?>

    <?php // echo $form->field($model, 'Time_priem_3') ?>

    <?php // echo $form->field($model, 'Time_priem_4') ?>

    <?php // echo $form->field($model, 'Time_priem_5') ?>

    <?php // echo $form->field($model, 'Time_priem_6') ?>

    <?php // echo $form->field($model, 'Time_priem_7') ?>

    <?php // echo $form->field($model, 'Time_priem_8') ?>

    <?php // echo $form->field($model, 'Time_priem_9') ?>

    <?php // echo $form->field($model, 'Time_priem_10') ?>

    <div class="form-group">
        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton('Reset', ['class' => 'btn btn-default']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
