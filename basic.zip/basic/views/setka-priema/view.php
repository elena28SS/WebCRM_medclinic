<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\SetkaPriema */

$this->title = $model->id;
$this->params['breadcrumbs'][] = ['label' => 'Setka Priemas', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="setka-priema-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Update', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Delete', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'Data_priema',
            'id_specialn',
            'id_sotrudnika',
            'Den_nedeli:ntext',
            'Time_priem_1',
            'Time_priem_2',
            'Time_priem_3',
            'Time_priem_4',
            'Time_priem_5',
            'Time_priem_6',
            'Time_priem_7',
            'Time_priem_8',
            'Time_priem_9',
            'Time_priem_10',
        ],
    ]) ?>

</div>
