<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\SetkaPriemaSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Сетка приема';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="setka-priema-index">

    <style>
        table.week thead{
            background: rgba(200,50,50,.7);
            color:white;
            font-weight: bold;
        }
        table.week thead th{
            text-align:center;
            padding: 5px;
        }
        table.week{
            border-color:silver;
        }
        table.week tbody tr td{
            height: 80px;
            color: #717171;
            font-weight: bold;
            padding: 2px;
        }
        .day-none{
            background: silver;
        }
    </style>


    <p>
        <?= Html::a('Записаться на прием', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <table width="70%" border="1" class="week">
        <thead>
        <th>пн</th>  <th>вт</th>
        <th>ср</th>  <th>чт</th>
        <th>пт</th>  <th>сб</th>
        <th>вс</th>
        </thead>
        <tbody>
            <?php
            foreach ($boundle as $week) {
                echo "<tr>\n";
                foreach ($week as $time => $day) {
                    if (!$day) {
                        echo "<td class=\"day-none\"></td>\n";
                    } else {
                        echo "<td>" . date('j', $time) . '<br/>';
                        if(is_object($day)){
                           $str = $day->idSotrudnika;
                            echo '<a href="/setka-priema/update?id='.$day->id.'" target="_blank">'.  $str->FIO.'<br/>';
                            if('00:00:00' != $day->Time_priem_1)
                                  echo '9:00-9:30<br/>';
                             if('00:00:00' != $day->Time_priem_2)
                                  echo '9:30-10:00<br/>';
                             if('00:00:00' != $day->Time_priem_3)
                                  echo '10:00-10:30<br/>';
                             if('00:00:00' != $day->Time_priem_4)
                                  echo '10:30-11:00<br/>';
                             if('00:00:00' != $day->Time_priem_5)
                                  echo '11:00-11:30<br/>';
                             if('00:00:00' != $day->Time_priem_6)
                                  echo '11:30-12:00<br/>';
                             if('00:00:00' != $day->Time_priem_7)
                                  echo '13:00-13:30<br/>';
                              if('00:00:00' != $day->Time_priem_8)
                                  echo '13:30-14:00<br/>';
                               if('00:00:00' != $day->Time_priem_9)
                                  echo '14:00-14:30<br/>';
                               if('00:00:00' != $day->Time_priem_10)
                                  echo '14:30-15:00<br/>';
                               echo '</a>';
                        }else{
                           echo "ЗАПИСЬ НЕ<br/>ВЕДЕТСЯ";
                        }
                        echo "</td>\n";
                    }
                }
                echo "</tr>\n";
            }
            ?>
        </tbody>
    </table>        

</div>
