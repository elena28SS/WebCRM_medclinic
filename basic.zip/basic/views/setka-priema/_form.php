<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\widgets\DatePicker;

/* @var $this yii\web\View */
/* @var $model app\models\SetkaPriema */
/* @var $form yii\widgets\ActiveForm */
 $sotrudniki = [];
        $rq = \app\models\Sotrudniki::find()->all();
        foreach ($rq as $val) {
            $sotrudniki[$val->id_sotr] = $val->FIO;
        }
        
        $spez = [];
        $rq = app\models\Tablzapisinapriem::find()->all();
        foreach ($rq as $val) {
            $spez[$val->id] = $val->Telefon_patienta;
        }
        
        
?>

<div class="setka-priema-form">

    <?php $form = ActiveForm::begin(); ?>



    <?=
    $form->field($model, 'Data_priema')->widget(DatePicker::className(), [
        'type' => DatePicker::TYPE_INPUT,
        'value' => (new \DateTime('now', new \DateTimeZone('Europe/Moscow'))),
        'pluginOptions' => [
            'format' => 'yyyy-mm-dd'
        ]
    ])
    ?>

    <?= $form->field($model, 'id_specialn')->dropDownList($spez)?>
    
    

    <?= $form->field($model, 'id_sotrudnika')->dropDownList($sotrudniki) ?>

    <div class="fluid-container">
        <div class="row">
            <div class="col-md-3">
                <?= $form->field($model, 'Time_priem_1')->checkbox() ?>
                <?= $form->field($model, 'Time_priem_2')->checkbox() ?>
                <?= $form->field($model, 'Time_priem_3')->checkbox() ?>
            </div>
            <div class="col-md-3">
                <?= $form->field($model, 'Time_priem_4')->checkbox() ?>
                <?= $form->field($model, 'Time_priem_5')->checkbox() ?>
                <?= $form->field($model, 'Time_priem_6')->checkbox() ?>
            </div>
            <div class="col-md-3">

                <?= $form->field($model, 'Time_priem_7')->checkbox() ?>
                <?= $form->field($model, 'Time_priem_8')->checkbox() ?>
                <?= $form->field($model, 'Time_priem_9')->checkbox() ?>
            </div>
            <div class="col-md-3">

                <?= $form->field($model, 'Time_priem_10')->checkbox() ?> 
            </div>
        </div>
        </di</div>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Сохранить' : 'Править', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
