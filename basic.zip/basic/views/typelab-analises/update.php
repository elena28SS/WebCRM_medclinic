<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\TypelabAnalises */

$this->title = Yii::t('app', 'Update {modelClass}: ', [
    'modelClass' => 'Typelab Analises',
]) . $model->id_type_analises;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Typelab Analises'), 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id_type_analises, 'url' => ['view', 'id' => $model->id_type_analises]];
$this->params['breadcrumbs'][] = Yii::t('app', 'Update');
?>
<div class="typelab-analises-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
