<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\InfoPatientsSearch */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="info-patients-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <?= $form->field($model, 'id_patient') ?>

    <?= $form->field($model, 'Data_create') ?>

    <?= $form->field($model, 'id_sotr_create') ?>

    <?= $form->field($model, 'gender') ?>

    <?= $form->field($model, 'FIO') ?>

    <?php // echo $form->field($model, 'Birhtday') ?>

    <?php // echo $form->field($model, 'Adress') ?>

    <?php // echo $form->field($model, 'City') ?>

    <?php // echo $form->field($model, 'street') ?>

    <?php // echo $form->field($model, 'SNILS') ?>

    <?php // echo $form->field($model, 'N_serya_Pasport') ?>

    <div class="form-group">
        <?= Html::submitButton(Yii::t('app', 'Search'), ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton(Yii::t('app', 'Reset'), ['class' => 'btn btn-default']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
