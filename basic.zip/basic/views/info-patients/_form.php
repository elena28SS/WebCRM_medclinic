
use kartik\datetime\DateTimePicker;
use yii\helpers\ArrayHelper;
use yii\helpers\Html;
use yii\widgets\ActiveForm;


/* @var $this yii\web\View */
/* @var $model app\models\InfoPatients */
/* @var $form yii\widgets\ActiveForm */


<div class="info-patients-form">

    <?php $form = ActiveForm::begin(); ?>
    
    <?= $form->field($model, 'Data_create')->widget(datetimePicker::classname(),[
    'type' => DateTimePicker::TYPE_COMPONENT_PREPEND,
    'value' => '23-02-1982 10:01',
    'pluginOptions' => [
        'autoclose'=>true,
        'format' => 'dd-mm-yyyy hh:ii'
    ]
]); ?>
    <?= $form->field($model, 'id_sotr_create')->textInput() ?>

    <?= $form->field($model, 'gender')->dropDownList([ 'жен' => 'жен', 'муж' => 'муж', '' => '', ], ['prompt' => '']) ?>

    <?= $form->field($model, 'FIO')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'Birhtday')->textInput() ?>

    <?= $form->field($model, 'Adress')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'City')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'street')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'SNILS')->textInput() ?>

    <?= $form->field($model, 'N_serya_Pasport')->textarea(['rows' => 6]) ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
