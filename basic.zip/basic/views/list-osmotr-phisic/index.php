<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\ListOsmotrPhisicSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Лист осмотра пациента');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="list-osmotr-phisic-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a(Yii::t('app', 'Создать лист осмотра'), ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            //['class' => 'yii\grid\SerialColumn'],

             [
            'attribute'=>'id_patient',
            'label'=>'ФИО больного',
            'format'=>'text', // Возможные варианты: raw, html
             'content'=>function($data){
              
             return $data->getPatientName();
         },
             'filter' => app\models\InfoPatients::getListdropdown(),                 
             ],
          [
            'attribute'=>'id_sotrudn',
            'label'=>'ФИО врача',
            'format'=>'text', // Возможные варианты: raw, html
             'content'=>function($data){
              
             return $data->getSotrudnikiName();
         },
             'filter' => app\models\Sotrudniki::getListdropdown(),
             ],
            'date_osmotra',
            'Respiratory_system:ntext',
             'Cardiovascular_system:ntext',
            // 'Gastrointestinal_tract:ntext',
            // 'Urogenitale_system:ntext',
            // 'Nervously_psychic_sphere:ntext',
            // 'Auscultatia_Chest:ntext',
            // 'Palpaciya_lymph_uzl:ntext',
            // 'heart_rate',
            // 'arterialAD',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
