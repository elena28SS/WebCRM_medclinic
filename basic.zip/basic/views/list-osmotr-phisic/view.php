<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\ListOsmotrPhisic */

$this->title = $model->id;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'List Osmotr Phisics'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="list-osmotr-phisic-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a(Yii::t('app', 'Update'), ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a(Yii::t('app', 'Delete'), ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => Yii::t('app', 'Are you sure you want to delete this item?'),
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'id_patient',
            'Id_sotrudn',
            'date_osmotra',
            'Respiratory_system:ntext',
            'Cardiovascular_system:ntext',
            'Gastrointestinal_tract:ntext',
            'Urogenitale_system:ntext',
            'Nervously_psychic_sphere:ntext',
            'Auscultatia_Chest:ntext',
            'Palpaciya_lymph_uzl:ntext',
            'heart_rate',
            'arterialAD',
        ],
    ]) ?>

</div>
