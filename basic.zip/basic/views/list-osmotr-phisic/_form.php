<?php
use kartik\datetime\DateTimePicker;
use yii\helpers\ArrayHelper;
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use app\models\InfoPatients;
use app\models\Sotrudniki
/* @var $this yii\web\View */
/* @var $model app\models\ListOsmotrPhisic */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="list-osmotr-phisic-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'id_patient')->dropDownList(ArrayHelper::map(InfoPatients::find()->select(['FIO','id_patient'])->orderBy('id_patient')->all(),'id_patient','FIO'),['prompt'=>''])?>

    <?= $form->field($model, 'Id_sotrudn')-> dropDownList(ArrayHelper::map(Sotrudniki::find()->select(['FIO','id_sotr'])->orderBy('id_sotr')->all(),'id_sotr','FIO'),['prompt'=>''])?>

    <?= $form->field($model, 'date_osmotra')-> widget(datetimePicker::classname(),[
    'type' => DateTimePicker::TYPE_COMPONENT_PREPEND,
    'value' => '2017-03-22 10:01',
    'pluginOptions' => [
        'autoclose'=>true,
        'format' => 'yyyy-mm-dd hh:ii'
    ] 
        ]);?>

    <?= $form->field($model, 'Respiratory_system')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'Cardiovascular_system')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'Gastrointestinal_tract')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'Urogenitale_system')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'Nervously_psychic_sphere')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'Auscultatia_Chest')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'Palpaciya_lymph_uzl')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'heart_rate')->textInput() ?>

    <?= $form->field($model, 'arterialAD')->textInput(['maxlength' => true]) ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
