<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\PriceProcLechSearch */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="price-proc-lech-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <?= $form->field($model, 'id_proc_lech') ?>

    <?= $form->field($model, 'ed_iz') ?>

    <?= $form->field($model, 'stoimost') ?>

    <?= $form->field($model, 'valuta') ?>

    <div class="form-group">
        <?= Html::submitButton(Yii::t('app', 'Search'), ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton(Yii::t('app', 'Reset'), ['class' => 'btn btn-default']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
