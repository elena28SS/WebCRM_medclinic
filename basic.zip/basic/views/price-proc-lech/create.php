<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\PriceProcLech */

$this->title = Yii::t('app', 'Create Price Proc Lech');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Price Proc Leches'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="price-proc-lech-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
