<?php
use yii\helpers\ArrayHelper;
use yii\helpers\Html;
use yii\grid\GridView;
use app\models\InfoPatients;
use app\models\LabAnalises;


/* @var $this yii\web\View */
/* @var $searchModel app\models\ListLabObsledovSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Лист лабораторного обследования');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="list-lab-obsledov-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a(Yii::t('app', 'Создать направление'), ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            [
            'attribute'=>'id_patient',
            'label'=>'ФИО больного',
            'format'=>'text', // Возможные варианты: raw, html
             'content'=>function($data){
              
             return $data->getPatientName();
         },
             'filter' => app\models\InfoPatients::getListdropdown(),                 
             ],
                 
            [
            'attribute'=>'id',
            'label'=>'Название лаб исследования',
            'format'=>'text', // Возможные варианты: raw, html
             'content'=>function($data){
              
             return $data->getLabAnalisesName();
         },
             'filter' => app\models\LabAnalises::getListdropdown(),                 
             ],
            'data_obsl',
            'id_sotr',
            // 'Result',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
