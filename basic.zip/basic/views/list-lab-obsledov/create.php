<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\ListLabObsledov */

$this->title = Yii::t('app', 'Create List Lab Obsledov');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'List Lab Obsledovs'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="list-lab-obsledov-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
