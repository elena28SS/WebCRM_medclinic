<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\ListLabObsledovSearch */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="list-lab-obsledov-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <?= $form->field($model, 'id') ?>

    <?= $form->field($model, 'id_patient') ?>

    <?= $form->field($model, 'id_analiz') ?>

    <?= $form->field($model, 'data_obsl') ?>

    <?= $form->field($model, 'id_sotr') ?>

    <?php // echo $form->field($model, 'Result') ?>

    <div class="form-group">
        <?= Html::submitButton(Yii::t('app', 'Search'), ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton(Yii::t('app', 'Reset'), ['class' => 'btn btn-default']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
