<?php
use kartik\datetime\DateTimePicker;
use yii\helpers\ArrayHelper;
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use app\models\InfoPatients;
use app\models\LabAnalises;


/* @var $this yii\web\View */
/* @var $model app\models\ListLabObsledov */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="list-lab-obsledov-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'id_patient')->dropDownList(ArrayHelper::map(InfoPatients::find()->select(['FIO','id_patient'])->orderBy('id_patient')->all(),'id_patient','FIO'),['prompt'=>''])?>

    <?= $form->field($model, 'id_analiz')->dropDownList(ArrayHelper::map(LabAnalises::find()->select(['name_analisa','id' ])->orderBy('id')->all(),'id','name_analisa'),['prompt'=>''])?>

    <?= $form->field($model, 'data_obsl')->textInput() ?>

    <?= $form->field($model, 'id_sotr')->textInput() ?>

    <?= $form->field($model, 'Result')->textInput(['maxlength' => true]) ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
