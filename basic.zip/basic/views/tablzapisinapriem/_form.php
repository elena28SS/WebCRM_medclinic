<?php
use kartik\date\DatePicker;
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $model app\models\Tablzapisinapriem */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="tablzapisinapriem-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'Data_priema')-> widget(\yii\jui\DatePicker::classname(), [     
     'options'=>['class'=>'form-control',],    
		'language' => 'ru',
		'dateFormat' => 'yyyy-MM-dd',
	]) ?>


    <?= $form->field($model, 'Vremia_priema')->textInput() ?>

    <?= $form->field($model, 'id_sotr')->dropDownList(ArrayHelper::map(app\models\Sotrudniki
            ::find()->select(['FIO','id_sotr'])->orderBy('id_sotr')->all(),'id_sotr','FIO'),['prompt'=>'']) ?>

    <?= $form->field($model, 'id_specialn')->dropDownList(ArrayHelper::map(app\models\SpecialisationSpr
            ::find()->select(['name_special','id'])->orderBy('id')->all(),'id','name_special'),['prompt'=>'']) ?>

    <?= $form->field($model, 'id_patient')->textInput() ?>

    <?= $form->field($model, 'Telefon_patienta')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'Diagnosis')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'Pervichniy')->textInput(['maxlength' => true]) ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Сохранить' : 'Править', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
