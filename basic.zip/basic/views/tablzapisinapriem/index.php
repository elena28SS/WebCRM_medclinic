<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\ArrayHelper;
/* @var $this yii\web\View */
/* @var $searchModel app\models\TablzapisinapriemSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Запись на прием';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="tablzapisinapriem-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Добавить запись на прием', ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            //['class' => 'yii\grid\SerialColumn'],

            'id',
            'Data_priema',
            'Vremia_priema',
            [
            'attribute'=>'id_sotr',
            'label'=>'ФИО врача',
            'format'=>'text', // Возможные варианты: raw, html
             'content'=>function($data){
              
             return $data->getSotrudnikiName();
         },
             'filter' => app\models\Sotrudniki::getListdropdown(),
   
             ],
      [      
    'attribute'=>'id_specialn',
            'label'=>'Cпециальность',
            'format'=>'text', // Возможные варианты: raw, html
             'content'=>function($data){
             
             return $data->getSpecialisationSprName();
         },
             'filter' => app\models\SpecialisationSpr::getListdropdown(),
   
             ],  
             'id_patient',
             'Telefon_patienta',
            // 'Diagnosis',
            // 'Pervichniy',

            ['class' => 'yii\grid\ActionColumn'],
        ],
           
    ]); ?>
</div>
