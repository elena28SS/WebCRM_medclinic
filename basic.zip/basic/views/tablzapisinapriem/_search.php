<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\TablzapisinapriemSearch */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="tablzapisinapriem-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <?= $form->field($model, 'id') ?>

    <?= $form->field($model, 'Data_priema') ?>

    <?= $form->field($model, 'Vremia_priema') ?>

    <?= $form->field($model, 'id_sotr') ?>

    <?= $form->field($model, 'id_specialn') ?>

    <?php // echo $form->field($model, 'id_patient') ?>

    <?php // echo $form->field($model, 'Telefon_patienta') ?>

    <?php // echo $form->field($model, 'Diagnosis') ?>

    <?php // echo $form->field($model, 'Pervichniy') ?>

    <div class="form-group">
        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton('Reset', ['class' => 'btn btn-default']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
