<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\ProcedLechSpr */

$this->title = Yii::t('app', 'Update {modelClass}: ', [
    'modelClass' => 'Proced Lech Spr',
]) . $model->id;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Proced Lech Sprs'), 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id, 'url' => ['view', 'id' => $model->id]];
$this->params['breadcrumbs'][] = Yii::t('app', 'Update');
?>
<div class="proced-lech-spr-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
