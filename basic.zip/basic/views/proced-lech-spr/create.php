<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\ProcedLechSpr */

$this->title = Yii::t('app', 'Create Proced Lech Spr');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Proced Lech Sprs'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="proced-lech-spr-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
