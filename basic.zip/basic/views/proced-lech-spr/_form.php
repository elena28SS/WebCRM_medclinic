<?php
use yii\helpers\ArrayHelper;
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use app\models\TypeProcLech
/* @var $this yii\web\View */
/* @var $model app\models\ProcedLechSpr */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="proced-lech-spr-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'id')-> dropDownList(ArrayHelper::map(TypeProcLech::find()->select(['name_type_lech','id'])->orderBy('id')->all(),'id','name_type_lech'),['prompt'=>''])?>

    <?= $form->field($model, 'name_procedure')->textarea(['rows' => 1]) ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
