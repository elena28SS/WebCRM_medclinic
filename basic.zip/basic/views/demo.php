

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

Patient
id
Adress
Birhtday
FIO
N_polisa

CartPatient
id
id_diagnozis
id_sotr
Anamnesis_morbi
Lechenie
id_uslugi


Users
id
status
login
passvord

Sotrudn
id_sotr
Id_doljn
FIO
telef

 Diagnosis_MKB10
kod MKB10
Categories_name

 Diagnosis
Kod_diagnosis MKB10
Name



