<?php
use kartik\datetime\DateTimePicker;
use yii\helpers\ArrayHelper;
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use app\models\InfoPatients;
use app\models\ProcedLechSpr;

/* @var $this yii\web\View */
/* @var $model app\models\ListLechProced */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="list-lech-proced-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'id_patient')->dropDownList(ArrayHelper::map(InfoPatients::find()->select(['FIO','id_patient'])->orderBy('id_patient')->all(),'id_patient','FIO'),['prompt'=>''])?>

    <?= $form->field($model, 'id_proced_lech')->dropDownList(ArrayHelper::map(ProcedLechSpr::find()->select(['name_procedure','id' ])->orderBy('id')->all(),'id','name_procedure'),['prompt'=>''])?>

    <?= $form->field($model, 'ed_izm')->textInput() ?>

    <?= $form->field($model, 'data_proc')->widget(datetimePicker::classname(),[
    'type' => DateTimePicker::TYPE_COMPONENT_PREPEND,
    'value' => '2017-03-22 10:01',
    'pluginOptions' => [
        'autoclose'=>true,
        'format' => 'yyyy-mm-dd hh:ii'
    ] 
        ]);?>

    <?= $form->field($model, 'cours_kol')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
