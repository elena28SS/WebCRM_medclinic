<?php
use yii\helpers\ArrayHelper;
use yii\helpers\Html;
use yii\grid\GridView;
use app\models\InfoPatients;
use app\models\ProcedLechSpr;

/* @var $this yii\web\View */
/* @var $searchModel app\models\ListLechProcedSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Лист лечения');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="list-lech-proced-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a(Yii::t('app', 'Создать лист лечения'), ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            //['class' => 'yii\grid\SerialColumn'],

            'id',
             [
            'attribute'=>'id_patient',
            'label'=>'ФИО больного',
            'format'=>'text', // Возможные варианты: raw, html
             'content'=>function($data){
              
             return $data->getPatientName();
         },
             'filter' => app\models\InfoPatients::getListdropdown(),                 
             ],
             [
            'attribute'=>'id_proc_lech',
            'label'=>'Название лечеб. проц',
            'format'=>'text', // Возможные варианты: raw, html
             'content'=>function($data){
              
             return $data->getProcedLechSprName();
         },
             'filter' => app\models\ProcedLechSpr::getListdropdown(),                 
             ],
            'ed_izm',
            'data_proc',
             'cours_kol',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
