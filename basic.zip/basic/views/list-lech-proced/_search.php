<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\ListLechProcedSearch */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="list-lech-proced-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <?= $form->field($model, 'id') ?>

    <?= $form->field($model, 'id_patient') ?>

    <?= $form->field($model, 'id_proced_lech') ?>

    <?= $form->field($model, 'ed_izm') ?>

    <?= $form->field($model, 'data_proc') ?>

    <?php // echo $form->field($model, 'cours_kol') ?>

    <div class="form-group">
        <?= Html::submitButton(Yii::t('app', 'Search'), ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton(Yii::t('app', 'Reset'), ['class' => 'btn btn-default']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
