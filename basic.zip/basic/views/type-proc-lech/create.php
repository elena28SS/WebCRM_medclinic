<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\TypeProcLech */

$this->title = Yii::t('app', 'Create Type Proc Lech');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Type Proc Leches'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="type-proc-lech-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
