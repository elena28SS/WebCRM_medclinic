<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\ListDiagnostObsl */

$this->title = 'Create List Diagnost Obsl';
$this->params['breadcrumbs'][] = ['label' => 'List Diagnost Obsls', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="list-diagnost-obsl-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
