<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\ListDiagnostObsl */

$this->title = 'Update List Diagnost Obsl: ' . $model->id;
$this->params['breadcrumbs'][] = ['label' => 'List Diagnost Obsls', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id, 'url' => ['view', 'id' => $model->id]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="list-diagnost-obsl-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
