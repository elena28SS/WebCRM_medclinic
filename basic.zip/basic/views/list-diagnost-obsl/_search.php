<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\ListDiagnostObslSearch */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="list-diagnost-obsl-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <?= $form->field($model, 'id') ?>

    <?= $form->field($model, 'id_patient') ?>

    <?= $form->field($model, 'id_diagnostic') ?>

    <?= $form->field($model, 'data_diagnostic') ?>

    <?= $form->field($model, 'id_sotr') ?>

    <?php // echo $form->field($model, 'Resultat') ?>

    <div class="form-group">
        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton('Reset', ['class' => 'btn btn-default']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
