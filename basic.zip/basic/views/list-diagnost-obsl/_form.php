<?php
use kartik\datetime\DateTimePicker;
 use app\models\DiagnostikaSpr;
use app\models\InfoPatients;
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $model app\models\ListDiagnostObsl */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="list-diagnost-obsl-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'id_patient')-> dropDownList(ArrayHelper::map(InfoPatients::find()->select(['FIO','id_patient'])->orderBy('id_patient')->all(),'id_patient','FIO'),['prompt'=>''])?>

    <?= $form->field($model, 'id_diagnostic')->dropDownList(ArrayHelper::map(DiagnostikaSpr::find()->select(['name_diagnjstik','id' ])->orderBy('id')->all(),'id','name_diagnjstik'),['prompt'=>''])?>

   <?= $form->field($model, 'data_diagnostic')-> widget(datetimePicker::classname(),[
    'type' => DateTimePicker::TYPE_COMPONENT_PREPEND,
    'value' => '23-Feb-1982 10:01',
    'pluginOptions' => [
        'autoclose'=>true,
        'format' => 'dd-M-yyyy hh:ii',
        'startDate' => '01-Mar-2014 12:00',
        'todayHighlight' => true
    ]
]); ?> 

    <?= $form->field($model, 'id_sotr')->textInput() ?>

    <?= $form->field($model, 'Resultat')->textInput(['maxlength' => true]) ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
