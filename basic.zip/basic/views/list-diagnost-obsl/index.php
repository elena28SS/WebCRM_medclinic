<?php
use yii\helpers\ArrayHelper;
use yii\helpers\Html;
use yii\grid\GridView;
use app\models\ListOsmotrPhisic;
/* @var $this yii\web\View */
/* @var $searchModel app\models\ListDiagnostObslSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Лист диагностического обследования';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="list-diagnost-obsl-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Создать  назначение', ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
          //  ['class' => 'yii\grid\SerialColumn'],

            'id',
             [
            'attribute'=>'id_patient',
            'label'=>'ФИО больного',
            'format'=>'text', // Возможные варианты: raw, html
             'content'=>function($data){
              
             return $data->getPatientName();
         },
             'filter' => app\models\InfoPatients::getListdropdown(),                 
             ],
           [
            'attribute'=>'id_diagnostic',
            'label'=>'Название диагностики',
            'format'=>'text', // Возможные варианты: raw, html
             'content'=>function($data){
              
             return $data->getDiagnostikaSprName();
         },
             'filter' => app\models\DiagnostikaSpr::getListdropdown(),                 
             ],
            'data_diagnostic',
            'id_sotr',
             'Resultat',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
