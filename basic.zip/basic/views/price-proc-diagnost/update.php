<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\PriceProcDiagnost */

$this->title = Yii::t('app', 'Update {modelClass}: ', [
    'modelClass' => 'Price Proc Diagnost',
]) . $model->id_proc_diagn;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Price Proc Diagnosts'), 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id_proc_diagn, 'url' => ['view', 'id' => $model->id_proc_diagn]];
$this->params['breadcrumbs'][] = Yii::t('app', 'Update');
?>
<div class="price-proc-diagnost-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
