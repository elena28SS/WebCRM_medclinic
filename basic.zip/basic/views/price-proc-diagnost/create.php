<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\PriceProcDiagnost */

$this->title = Yii::t('app', 'Create Price Proc Diagnost');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Price Proc Diagnosts'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="price-proc-diagnost-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
