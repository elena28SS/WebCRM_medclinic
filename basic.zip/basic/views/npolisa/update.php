<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\NPolisa */

$this->title = Yii::t('app', 'Update {modelClass}: ', [
    'modelClass' => 'Npolisa',
]) . $model->N_polisa;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Npolisas'), 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->N_polisa, 'url' => ['view', 'id' => $model->N_polisa]];
$this->params['breadcrumbs'][] = Yii::t('app', 'Update');
?>
<div class="npolisa-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
