<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\PostDoljnost */

$this->title = Yii::t('app', 'Update {modelClass}: ', [
    'modelClass' => 'Post Doljnost',
]) . $model->id_doljn;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Post Doljnosts'), 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id_doljn, 'url' => ['view', 'id' => $model->id_doljn]];
$this->params['breadcrumbs'][] = Yii::t('app', 'Update');
?>
<div class="post-doljnost-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
