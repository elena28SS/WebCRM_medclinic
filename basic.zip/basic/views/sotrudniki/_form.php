<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Sotrudniki */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="sotrudniki-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'id_sotr')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'FIO')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'id_doljn')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'telef')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'stage_rabot_let')->textInput() ?>

    <?= $form->field($model, 'god_vipuska')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'id_specializ')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
