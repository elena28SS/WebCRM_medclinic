<?php
use app\models\PostDoljnost;
use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\ArrayHelper;
/* @var $this yii\web\View */
/* @var $searchModel app\models\SotrudnikiSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Сотрудники';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="sotrudniki-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Добавить сотрудника', ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
           // ['class' => 'yii\grid\SerialColumn'],

             [
            'attribute'=>'id_doljn',
            'label'=>'Должность',
            'format'=>'text', // Возможные варианты: raw, html
             'content'=>function($data){
             
             return $data->getPostDoljnostName();
         },
             'filter' => app\models\PostDoljnost::getListdropdown(),
   
             ],

            'FIO:ntext',            
            'telef',
            'stage_rabot_let',
            // 'god_vipuska',
             
               [
            'attribute'=>'id_specializ',
            'label'=>'Cпециальность',
            'format'=>'text', // Возможные варианты: raw, html
             'content'=>function($data){
             
             return $data->getSpecialisationSprName();
         },
             'filter' => app\models\SpecialisationSpr::getListdropdown(),
   
             ],   

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
