<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "Type_priem".
 *
 * @property integer $id
 * @property integer $id_ specialn
 * @property string $vremia_pr
 *
 * @property Raspisanie[] $raspisanies
 */
class TypePriem extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'Type_priem';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id_specialn', 'vremia_pr'], 'required'],
            [['id_specialn'], 'integer'],
            [['vremia_pr'], 'string'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'id_specialn' => 'Id Specialn',
            'vremia_pr' => 'Vremia Pr',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRaspisanies()
    {
        return $this->hasMany(Raspisanie::className(), ['id_type_priema' => 'id']);
    }

    /**
     * @inheritdoc
     * @return TypePriemQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new TypePriemQuery(get_called_class());
    }
}
