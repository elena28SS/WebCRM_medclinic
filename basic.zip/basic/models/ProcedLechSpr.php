<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "Proced_lech_spr".
 *
 * @property integer $id
 * @property integer $type
 * @property string $name_procedure
 *
 * @property TypeProcLech $type0
 */
class ProcedLechSpr extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'Proced_lech_spr';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['type', 'name_procedure'], 'required'],
            [['type'], 'integer'],
            [['name_procedure'], 'string'],
            [['type'], 'exist', 'skipOnError' => true, 'targetClass' => TypeProcLech::className(), 'targetAttribute' => ['type' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'type' => 'Тип лечение',
            'name_procedure' => 'название процедуры',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getType0()
    {
        return $this->hasOne(TypeProcLech::className(), ['id' => 'type']);
    }
     public function getTypeProcLechName()       
     {
     return $this->type0->name_type_lech;  
     }
      public static function getListdropdown() {
        
       return \yii\helpers\ArrayHelper::map(self::find()->all(), 'id', 'name_procedure'); 
     }
}
