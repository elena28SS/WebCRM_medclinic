<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "Info_Patients".
 *
 * @property integer $id_patient
 * @property string $Data_create
 * @property integer $id_sotr_create
 * @property string $gender
 * @property string $FIO
 * @property string $Birhtday
 * @property string $Adress
 * @property string $City
 * @property string $street
 * @property integer $SNILS
 * @property string $N_serya_Pasport
 */
class InfoPatients extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'Info_Patients';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['Data_create', 'Birhtday'], 'safe'],
            [['id_sotr_create', 'gender', 'FIO', 'Birhtday', 'Adress', 'City', 'street', 'SNILS', 'N_serya_Pasport'], 'required'],
            [['id_sotr_create', 'SNILS'], 'integer'],
            [['gender', 'FIO', 'City', 'street', 'N_serya_Pasport'], 'string'],
            [['Adress'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_patient' => Yii::t('app', 'Id Пациента'),
            'Data_create' => Yii::t('app', 'Дата создания'),
            'id_sotr_create' => Yii::t('app', ' ФИО сотр'),
            'gender' => Yii::t('app', 'пол'),
            'FIO' => Yii::t('app', 'ФИО пациента'),
            'Birhtday' => Yii::t('app', 'Дата рожд'),
            'Adress' => Yii::t('app', 'Адрес'),
            'City' => Yii::t('app', 'Город'),
            'street' => Yii::t('app', 'Улица'),
            'SNILS' => Yii::t('app', 'Snils'),
            'N_serya_Pasport' => Yii::t('app', 'N-серия паспорта'),
        ];
    }
    public function getIdPatient()
    {
        return $this->hasOne(CartPatient::className(), ['id_patient' => 'id_patient']);
    }
    public static function getListdropdown() {
        
        return \yii\helpers\ArrayHelper::map(self::find()->all(), 'id_patient', 'FIO');   
    }
    
}
