<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "Post_doljnost".
 *
 * @property string $id_doljn
 * @property string $nazvanie
 *
 * @property Sotrudniki[] $sotrudnikis
 * @property Sotrudniki[] $sotrudnikis0
 */
class PostDoljnost extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'Post_doljnost';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['nazvanie'], 'required'],
            [['nazvanie'], 'string'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_doljn' => 'Id должности',
            'nazvanie' => 'Название должн',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
   

    /**
     * @return \yii\db\ActiveQuery
     */
    
    
    public static function getListdropdown() {
        
        return \yii\helpers\ArrayHelper::map(self::find()->all(), 'id_doljn', 'nazvanie');   
    }
}
