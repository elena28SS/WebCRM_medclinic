<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "ListOsmotrPhisic".
 *
 * @property string $id
 * @property integer $id_patient
 * @property integer $Id_sotrudn
 * @property string $date_osmotra
 * @property string $Respiratory_system
 * @property string $Cardiovascular_system
 * @property string $Gastrointestinal_tract
 * @property string $Urogenitale_system
 * @property string $Nervously_psychic_sphere
 * @property string $Auscultatia_Chest
 * @property string $Palpaciya_lymph_uzl
 * @property integer $heart_rate
 * @property string $arterialAD
 */
class ListOsmotrPhisic extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'ListOsmotrPhisic';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id_patient', 'Id_sotrudn', 'date_osmotra', 'Respiratory_system', 'Cardiovascular_system', 'Gastrointestinal_tract', 'Urogenitale_system', 'Nervously_psychic_sphere', 'Auscultatia_Chest', 'Palpaciya_lymph_uzl', 'heart_rate', 'arterialAD'], 'required'],
            [['id_patient', 'Id_sotrudn', 'heart_rate'], 'integer'],
            [['date_osmotra'], 'safe'],
            [['Respiratory_system', 'Cardiovascular_system', 'Gastrointestinal_tract', 'Urogenitale_system', 'Nervously_psychic_sphere', 'Auscultatia_Chest', 'Palpaciya_lymph_uzl'], 'string'],
            [['arterialAD'], 'string', 'max' => 16],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
           // 'id' => Yii::t('app', 'ID'),
            'id_patient' => Yii::t('app', 'Id Pпациента'),
            'Id_sotrudn' => Yii::t('app', 'ФИО врача'),
            'date_osmotra' => Yii::t('app', 'Дата осмотра'),
            'Respiratory_system' => Yii::t('app', 'Дыхательная с-ма'),
            'Cardiovascular_system' => Yii::t('app', 'Серд-сосуд с-ма'),
            'Gastrointestinal_tract' => Yii::t('app', 'ЖКТ'),
            'Urogenitale_system' => Yii::t('app', 'Мочеполовая сма'),
            'Nervously_psychic_sphere' => Yii::t('app', ' нервно-психич статус'),
            'Auscultatia_Chest' => Yii::t('app', 'Аускультация гр клетки'),
            'Palpaciya_lymph_uzl' => Yii::t('app', 'Лимфатическая ситема'),
            'heart_rate' => Yii::t('app', 'ЧСС`'),
            'arterialAD' => Yii::t('app', ' Артер давление мм рт ст'),
        ];
    }
    
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getid_patient0()
    {
      return $this->hasOne(InfoPatients::className(), ['id_patient' => 'id_patient']);
    }
      public function getPatientName()       
   {
    return $this-> id_patient0->FIO;  
   }
    public function getid_sotrudn0()
    {
        return $this->hasOne(Sotrudniki::className(), ['id_sotr' => 'Id_sotrudn']);
    }
     public function getSotrudnikiName()       
   {
    return $this-> id_sotrudn0->FIO;  
   }
   
   public static function getListdropdown() {
        
        return \yii\helpers\ArrayHelper::map(self::find()->all(), 'id_sotr', 'FIO');   
    }
}
