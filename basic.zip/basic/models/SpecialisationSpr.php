<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "Specialisation_Spr".
 *
 * @property integer $id
 * @property string $name_special
 *
 * @property Sotrudniki[] $sotrudnikis
 */
class SpecialisationSpr extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'Specialisation_Spr';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name_special'], 'required'],
            [['name_special'], 'string'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name_special' => 'Название специализации',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
   
    
    public static function getListdropdown() {
        
        return \yii\helpers\ArrayHelper::map(self::find()->all(), 'id', 'name_special');   
    }
}
