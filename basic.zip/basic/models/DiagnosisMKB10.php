<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "DiagnosisMKB10".
 *
 * @property string $diagnosis_name
 * @property string $kod MKB10
 *
 * @property CartPatient $kodMKB10
 * @property CartPatient $kodMKB100
 * @property CartPatient $kodMKB101
 */
class DiagnosisMKB10 extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'DiagnosisMKB10';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['diagnosis_name', 'kod MKB10'], 'required'],
            [['diagnosis_name'], 'string'],
            [['kod MKB10'], 'string', 'max' => 50],
            [['kod MKB10'], 'exist', 'skipOnError' => true, 'targetClass' => CartPatient::className(), 'targetAttribute' => ['kod MKB10' => 'kod_Mkb10_main_ds']],
            [['kod MKB10'], 'exist', 'skipOnError' => true, 'targetClass' => CartPatient::className(), 'targetAttribute' => ['kod MKB10' => 'current_ds_Mkb10']],
            [['kod MKB10'], 'exist', 'skipOnError' => true, 'targetClass' => CartPatient::className(), 'targetAttribute' => ['kod MKB10' => 'backgrd_ds_Mkb10']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'diagnosis_name' => 'Diagnosis Name',
            'kod MKB10' => 'Kod  Mkb10',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getKodMKB10()
    {
        return $this->hasOne(CartPatient::className(), ['kod_Mkb10_main_ds' => 'kod MKB10']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getKodMKB100()
    {
        return $this->hasOne(CartPatient::className(), ['current_ds_Mkb10' => 'kod MKB10']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getKodMKB101()
    {
        return $this->hasOne(CartPatient::className(), ['backgrd_ds_Mkb10' => 'kod MKB10']);
    }
}
