<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "ClassMKB10".
 *
 * @property integer $id
 * @property string $class_MKB10
 * @property string $Name
 */
class ClassMKB10 extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'ClassMKB10';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['class_MKB10', 'Name'], 'required'],
            [['Name'], 'string'],
            [['class_MKB10'], 'string', 'max' => 225],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'class_MKB10' => Yii::t('app', 'Class  Mkb10'),
            'Name' => Yii::t('app', 'Name'),
        ];
    }
}
