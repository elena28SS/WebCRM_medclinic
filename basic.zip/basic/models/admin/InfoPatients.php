<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "Info_Patients".
 *
 * @property string $Data_create
 * @property integer $id_sotr_create
 * @property integer $id_patient
 * @property string $gender
 * @property string $FIO
 * @property string $Birhtday
 * @property string $Adress
 * @property string $City
 * @property string $street
 * @property integer $N_polisa
 * @property integer $id_company_ens
 * @property integer $SNILS
 * @property string $N_serya_Pasport
 *
 * @property CartPatient $cartPatient
 * @property CompanyEnsurance $companyEnsurance
 * @property CartPatient $idPatient
 * @property CompanyEnsurance $idCompanyEns
 */
class InfoPatients extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'Info_Patients';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['Data_create', 'id_sotr_create', 'id_patient', 'gender', 'FIO', 'Birhtday', 'Adress', 'City', 'street', 'N_polisa', 'id_company_ens', 'SNILS', 'N_serya_Pasport'], 'required'],
            [['Data_create', 'Birhtday'], 'safe'],
            [['id_sotr_create', 'id_patient', 'N_polisa', 'id_company_ens', 'SNILS'], 'integer'],
            [['gender', 'FIO', 'City', 'street'], 'string'],
            [['Adress'], 'string', 'max' => 50],
            [['N_serya_Pasport'], 'string', 'max' => 50],
            [['id_patient'], 'exist', 'skipOnError' => true, 'targetClass' => CartPatient::className(), 'targetAttribute' => ['id_patient' => 'id_patient']],
            [['id_company_ens'], 'exist', 'skipOnError' => true, 'targetClass' => CompanyEnsurance::className(), 'targetAttribute' => ['id_company_ens' => 'id_company_ens']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'Data_create' => 'Data Create',
            'id_sotr_create' => 'Id Sotr Create',
            'id_patient' => 'Id Patient',
            'gender' => 'Gender',
            'FIO' => 'Fio',
            'Birhtday' => 'Birhtday',
            'Adress' => 'Adress',
            'City' => 'City',
            'street' => 'Street',
            'N_polisa' => 'N Polisa',
            'id_company_ens' => 'Id Company Ens',
            'SNILS' => 'Snils',
            'N_serya_Pasport' => 'N Serya  Pasport',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCartPatient()
    {
        return $this->hasOne(CartPatient::className(), ['id_patient' => 'id_patient']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCompanyEnsurance()
    {
        return $this->hasOne(CompanyEnsurance::className(), ['id_company_ens' => 'id_company_ens']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdPatient()
    {
        return $this->hasOne(CartPatient::className(), ['id_patient' => 'id_patient']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdCompanyEns()
    {
        return $this->hasOne(CompanyEnsurance::className(), ['id_company_ens' => 'id_company_ens']);
    }
}
