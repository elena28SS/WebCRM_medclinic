<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "CartPatient".
 *
 * @property integer $id_patient
 * @property string $id_sotr
 * @property string $Complains
 * @property string $Lecheniye
 * @property string $Anamnesis_morbi
 * @property string $Anamnesis_vitae
 * @property string $Lek_tolerance/allergye
 * @property string $kod_Mkb10_main_ds
 * @property string $current_ds_Mkb10
 * @property string $backgrd_ds_Mkb10
 * @property string $Epicrysis
 *
 * @property DiagnosisMKB10 $kodMkb10MainDs
 * @property DiagnosisMKB10 $currentDsMkb10
 * @property DiagnosisMKB10 $backgrdDsMkb10
 * @property InfoPatients $idPatient
 * @property Sotrudniki $idSotr
 * @property InfoPatients $infoPatients
 * @property ListLabObsledov $listLabObsledov
 * @property ListLechProced $listLechProced
 * @property OsmotrPhisic $osmotrPhisic
 */
class CartPatient extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'CartPatient';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id_patient', 'id_sotr', 'Complains', 'Lecheniye', 'Anamnesis_morbi', 'Anamnesis_vitae', 'Lek_tolerance/allergye', 'kod_Mkb10_main_ds', 'current_ds_Mkb10', 'backgrd_ds_Mkb10', 'Epicrysis'], 'required'],
            [['id_patient', 'id_sotr'], 'integer'],
            [['Complains', 'Lecheniye', 'Anamnesis_morbi', 'Anamnesis_vitae', 'Lek_tolerance/allergye', 'Epicrysis'], 'string'],
            [['kod_Mkb10_main_ds', 'current_ds_Mkb10', 'backgrd_ds_Mkb10'], 'string', 'max' => 50],
            [['kod_Mkb10_main_ds'], 'exist', 'skipOnError' => true, 'targetClass' => DiagnosisMKB10::className(), 'targetAttribute' => ['kod_Mkb10_main_ds' => 'kod MKB10']],
            [['current_ds_Mkb10'], 'exist', 'skipOnError' => true, 'targetClass' => DiagnosisMKB10::className(), 'targetAttribute' => ['current_ds_Mkb10' => 'kod MKB10']],
            [['backgrd_ds_Mkb10'], 'exist', 'skipOnError' => true, 'targetClass' => DiagnosisMKB10::className(), 'targetAttribute' => ['backgrd_ds_Mkb10' => 'kod MKB10']],
            [['id_patient'], 'exist', 'skipOnError' => true, 'targetClass' => InfoPatients::className(), 'targetAttribute' => ['id_patient' => 'id_patient']],
            [['id_sotr'], 'exist', 'skipOnError' => true, 'targetClass' => Sotrudniki::className(), 'targetAttribute' => ['id_sotr' => 'id_sotr']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_patient' => 'Id Patient',
            'id_sotr' => 'Id Sotr',
            'Complains' => 'Complains',
            'Lecheniye' => 'Lecheniye',
            'Anamnesis_morbi' => 'Anamnesis Morbi',
            'Anamnesis_vitae' => 'Anamnesis Vitae',
            'Lek_tolerance/allergye' => 'Lek Tolerance/allergye',
            'kod_Mkb10_main_ds' => 'Kod  Mkb10 Main Ds',
            'current_ds_Mkb10' => 'Current Ds  Mkb10',
            'backgrd_ds_Mkb10' => 'Backgrd Ds  Mkb10',
            'Epicrysis' => 'Epicrysis',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getKodMkb10MainDs()
    {
        return $this->hasOne(DiagnosisMKB1::className(), ['kod MKB10' => 'kod_Mkb10_main_ds']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCurrentDsMkb10()
    {
        return $this->hasOne(DiagnosisMKB10::className(), ['kod MKB10' => 'current_ds_Mkb10']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getBackgrdDsMkb10()
    {
        return $this->hasOne(DiagnosisMKB10::className(), ['kod MKB10' => 'backgrd_ds_Mkb10']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdPatient()
    {
        return $this->hasOne(InfoPatients::className(), ['id_patient' => 'id_patient']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdSotr()
    {
        return $this->hasOne(Sotrudniki::className(), ['id_sotr' => 'id_sotr']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getInfoPatients()
    {
        return $this->hasOne(InfoPatients::className(), ['id_patient' => 'id_patient']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getListLabObsledov()
    {
        return $this->hasOne(ListLabObsledov::className(), ['id_patient' => 'id_patient']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getListLechProced()
    {
        return $this->hasOne(ListLechProced::className(), ['id_patienta' => 'id_patient']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getOsmotrPhisic()
    {
        return $this->hasOne(OsmotrPhisic::className(), ['id_patient' => 'id_patient']);
    }
}
