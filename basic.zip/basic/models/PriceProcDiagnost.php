<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "Price_proc_diagnost".
 *
 * @property integer $id_proc_diagn
 * @property string $ed_iz
 * @property string $stoimost
 * @property string $valuta
 *
 * @property DiagnostikaSpr $diagnostikaSpr
 */
class PriceProcDiagnost extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'Price_proc_diagnost';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id_proc_diagn', 'ed_iz', 'stoimost', 'valuta'], 'required'],
            [['id_proc_diagn'], 'integer'],
            [['ed_iz', 'valuta'], 'string'],
            [['stoimost'], 'number'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_proc_diagn' => 'Id Proc Diagn',
            'ed_iz' => 'Ed Iz',
            'stoimost' => 'Stoimost',
            'valuta' => 'Valuta',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getDiagnostikaSpr()
    {
        return $this->hasOne(DiagnostikaSpr::className(), ['id_proc_diagn' => 'id_proc_diagn']);
    }
}
