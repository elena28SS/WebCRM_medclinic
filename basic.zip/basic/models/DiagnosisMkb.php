<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "Diagnosis_mkb".
 *
 * @property string $id
 * @property string $diagnosis_name
 * @property string $kod_mkb_10
 *
 * @property ClassifMkbDs $kodMkb10
 */
class DiagnosisMkb extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'Diagnosis_mkb';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['diagnosis_name', 'kod_mkb_10'], 'required'],
            [['diagnosis_name'], 'string'],
            [['kod_mkb_10'], 'string', 'max' => 100],
            [['kod_mkb_10'], 'exist', 'skipOnError' => true, 'targetClass' => ClassifMkbDs::className(), 'targetAttribute' => ['kod_mkb_10' => 'class_MKB10']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'diagnosis_name' => 'Diagnosis Name',
            'kod_mkb_10' => 'Kod Mkb 10',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getKodMkb10()
    {
        return $this->hasOne(ClassifMkbDs::className(), ['class_MKB10' => 'kod_mkb_10']);
    }
}
