<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "common_id_lech".
 *
 * @property integer $id
 * @property integer $id_typeLech
 * @property integer $id_Lech
 *
 * @property CommonIdLech $idLech
 * @property CommonIdLech[] $commonIdLeches
 */
class CommonIdLech extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'common_id_lech';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'id_typeLech', 'id_Lech'], 'required'],
            [['id', 'id_typeLech', 'id_Lech'], 'integer'],
            [['id_Lech'], 'exist', 'skipOnError' => true, 'targetClass' => CommonIdLech::className(), 'targetAttribute' => ['id_Lech' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'id_typeLech' => 'Id Type Lech',
            'id_Lech' => 'Id  Lech',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdLech()
    {
        return $this->hasOne(CommonIdLech::className(), ['id' => 'id_Lech']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCommonIdLeches()
    {
        return $this->hasMany(CommonIdLech::className(), ['id_Lech' => 'id']);
    }
}
