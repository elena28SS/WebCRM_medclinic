<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "ClassifMkb_ds".
 *
 * @property integer $id
 * @property string $class_MKB10
 * @property string $Name
 *
 * @property DiagnosisMkb[] $diagnosisMkbs
 */
class ClassifMkbDs extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'ClassifMkb_ds';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['class_MKB10', 'Name'], 'required'],
            [['Name'], 'string'],
            [['class_MKB10'], 'string', 'max' => 50],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'class_MKB10' => 'Class  Mkb10',
            'Name' => 'Name',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getDiagnosisMkbs()
    {
        return $this->hasMany(DiagnosisMkb::className(), ['kod_mkb_10' => 'class_MKB10']);
    }
}
