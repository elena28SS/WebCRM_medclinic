<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "Sotrudniki".
 *
 * @property string $id_sotr
 * @property string $FIO
 * @property string $id_doljn
 * @property string $telef
 * @property integer $stage_rabot_let
 * @property string $god_vipuska
 * @property integer $id_specializ
 *
 * @property CartPatient $idSotr
 * @property Tablzapisinapriem[] $tablzapisinapriems
 */
class Sotrudniki extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'Sotrudniki';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['FIO', 'id_doljn', 'telef', 'stage_rabot_let', 'god_vipuska', 'id_specializ'], 'required'],
            [['FIO'], 'string'],
            [['id_doljn', 'telef', 'stage_rabot_let', 'id_specializ','id_sotr'], 'integer'],
            [['god_vipuska'], 'safe'],
            [['id_sotr'], 'exist', 'skipOnError' => true, 'targetClass' => CartPatient::className(), 'targetAttribute' => ['id_sotr' => 'id_sotr']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_sotr' => 'Id сотруд',
            'FIO' => 'ФИО ',
            'id_doljn' => 'Должность',
            'telef' => 'Телефон',
            'stage_rabot_let' => 'Стаж работы, лет',
            'god_vipuska' => 'Год выпуска',
            'id_specializ' => 'Специализация',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdSotr()
    {
        return $this->hasOne(CartPatient::className(), ['id_sotr' => 'id_sotr']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTablzapisinapriems()
    {
        return $this->hasMany(Tablzapisinapriem::className(), ['id_sotr' => 'id_sotr']);
    }
    
    public static function getListdropdown() {
        
        return \yii\helpers\ArrayHelper::map(self::find()->all(), 'id_sotr', 'FIO');   
    }
    
   /** public function getid_patient0()
    {
        return $this->hasOne(InfoPatients::className(), ['id_patient' => 'id_patient']);
    }
      public function getPatientName()       
   {
    return $this-> id_patient0->FIO;
   }
   */
    //---
     public function getid_specializ0()
    {
        return $this->hasOne(SpecialisationSpr::className(), ['id' => 'id_specializ']);
    }
    public function getSpecialisationSprName()       
    {
    return $this->id_specializ0->name_special;  
    }
    //---
     public function getid_doljn0()
    {
        return $this->hasOne(PostDoljnost::className(), ['id_doljn' => 'id_doljn']);
    }
    public function getPostDoljnostName()       
    {
    return $this->id_doljn0->nazvanie;  
    }
}
