<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "Diagnostika_spr".
 *
 * @property integer $id_type_diagnjstiki
 * @property integer $id
 * @property string $name_diagnjstik
 *
 * @property TypeDiagnostika $idTypeDiagnjstiki
 */
class DiagnostikaSpr extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'Diagnostika_spr';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id_type_diagnjstiki', 'name_diagnjstik'], 'required'],
            [['id_type_diagnjstiki'], 'integer'],
            [['name_diagnjstik'], 'string'],
            [['id_type_diagnjstiki'], 'exist', 'skipOnError' => true, 'targetClass' => TypeDiagnostika::className(), 'targetAttribute' => ['id_type_diagnjstiki' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_type_diagnjstiki' => 'Тип диагностики',
            'id' => 'ID',
            'name_diagnjstik' => 'Название типа',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getType0()
    {
        return $this->hasOne(TypeDiagnostika::className(), ['id' => 'id_type_diagnjstiki']);
    }
     
   public function getTypeDiagnostikaName()       
   {
   return $this->type0 ->name_type_diagnproc;  
   }
   //выпадающий лист диагностики
    public static function getListdropdown() {
        
        return \yii\helpers\ArrayHelper::map(self::find()->all(), 'id', 'name_diagnjstik');   
    }
}
