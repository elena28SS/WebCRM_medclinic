<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "CartPatient".
 *
 * @property integer $id_patient
 * @property string $id_sotr
 * @property string $Complains
 * @property string $Lecheniye
 * @property string $Anamnesis_morbi
 * @property string $Anamnesis_vitae
 * @property string $Lek_allergye
 * @property string $kod_Mkb10
 * @property string $Name_Diagnozis
 * @property string $Epicrysis
 *
 * @property InfoPatients $idPatient
 * @property Sotrudniki $sotrudniki
 */
class CartPatient extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'CartPatient';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id_sotr', 'Complains', 'Lecheniye', 'Anamnesis_morbi', 'Anamnesis_vitae', 'Lek_allergye', 'kod_Mkb10', 'Name_Diagnozis', 'Epicrysis'], 'required'],
            [['id_sotr'], 'integer'],
            [['Complains', 'Lecheniye', 'Anamnesis_morbi', 'Anamnesis_vitae', 'Lek_allergye', 'Name_Diagnozis', 'Epicrysis'], 'string'],
            [['kod_Mkb10'], 'string', 'max' => 50],
            [['id_patient'], 'exist', 'skipOnError' => true, 'targetClass' => InfoPatients::className(), 'targetAttribute' => ['id_patient' => 'id_patient']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_patient' => Yii::t('app', 'Id Patient'),
            'id_sotr' => Yii::t('app', 'Лечащий врач'),
            'Complains' => Yii::t('app', 'Жалобы'),
            'Lecheniye' => Yii::t('app', 'Лечение'),
            'Anamnesis_morbi' => Yii::t('app', 'Анамнез болезни'),
            'Anamnesis_vitae' => Yii::t('app', 'Анамнез жизни'),
            'Lek_allergye' => Yii::t('app', 'Лек аллергия'),
            'kod_Mkb10' => Yii::t('app', 'Kod  Mkb10'),
            'Name_Diagnozis' => Yii::t('app', 'Диагноз'),
            'Epicrysis' => Yii::t('app', 'Эпикриз'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getid_patient0()
    {
        return $this->hasOne(InfoPatients::className(), ['id_patient' => 'id_patient']);
    }
      public function getPatientName()       
   {
    return $this-> id_patient0->FIO;  
   }
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getid_sotr0()
    {
        return $this->hasOne(Sotrudniki::className(), ['id_sotr' => 'id_sotr']);
    }
     public function getSotrudnikiName()       
   {
    return $this-> id_sotr0->FIO;  
   }
   public static function getListdropdown() {
        
        return \yii\helpers\ArrayHelper::map(self::find()->all(), 'id_sotr', 'FIO');   
    }
}
