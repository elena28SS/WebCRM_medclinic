<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "OsmotrPhisic".
 *
 * @property integer $id_patient
 * @property integer $Id_sotrudn
 * @property string $date_osmotra
 * @property string $Respiratory_system
 * @property string $Cardiovascular_system
 * @property string $Gastrointestinal_tract
 * @property string $Urogenitale_system
 * @property string $Nervously_psychic_sphere
 * @property string $Auscultatia_Chest
 * @property string $Palpaciya_lymph_uzl
 * @property integer $heart_rate
 * @property string $arterialAD
 *
 * @property CartPatient $idPatient
 */
class OsmotrPhisic extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'OsmotrPhisic';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id_patient', 'Id_sotrudn', 'date_osmotra', 'Respiratory_system', 'Cardiovascular_system', 'Gastrointestinal_tract', 'Urogenitale_system', 'Nervously_psychic_sphere', 'Auscultatia_Chest', 'Palpaciya_lymph_uzl', 'heart_rate', 'arterialAD'], 'required'],
            [['id_patient', 'Id_sotrudn', 'heart_rate'], 'integer'],
            [['date_osmotra'], 'safe'],
            [['Respiratory_system', 'Cardiovascular_system', 'Gastrointestinal_tract', 'Urogenitale_system', 'Nervously_psychic_sphere', 'Auscultatia_Chest', 'Palpaciya_lymph_uzl'], 'string'],
            [['arterialAD'], 'string', 'max' => 16],
            [['id_patient'], 'exist', 'skipOnError' => true, 'targetClass' => CartPatient::className(), 'targetAttribute' => ['id_patient' => 'id_patient']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_patient' => 'Id Patient',
            'Id_sotrudn' => 'Id Sotrudn',
            'date_osmotra' => 'Date Osmotra',
            'Respiratory_system' => 'Respiratory System',
            'Cardiovascular_system' => 'Cardiovascular System',
            'Gastrointestinal_tract' => 'Gastrointestinal Tract',
            'Urogenitale_system' => 'Urogenitale System',
            'Nervously_psychic_sphere' => 'Nervously Psychic Sphere',
            'Auscultatia_Chest' => 'Auscultatia  Chest',
            'Palpaciya_lymph_uzl' => 'Palpaciya Lymph Uzl',
            'heart_rate' => 'Heart Rate',
            'arterialAD' => 'Arterial Ad',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdPatient()
    {
        return $this->hasOne(CartPatient::className(), ['id_patient' => 'id_patient']);
    }
}
