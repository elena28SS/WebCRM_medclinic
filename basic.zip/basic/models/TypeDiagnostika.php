<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "Type_Diagnostika".
 *
 * @property integer $id
 * @property string $name_type_diagnproc
 *
 * @property DiagnostikaSpr[] $diagnostikaSprs
 */
class TypeDiagnostika extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'Type_Diagnostika';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name_type_diagnproc'], 'required'],
            [['name_type_diagnproc'], 'string'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name_type_diagnproc' => 'Тип диагностики',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
   
     public static function getListdropdown() {
        
        return \yii\helpers\ArrayHelper::map(self::find()->all(), 'id', 'name_type_diagnproc');   
    }
}
