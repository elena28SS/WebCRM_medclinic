<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "Setka_priema".
 *
 * @property integer $id
 * @property string $Data_priema
 * @property integer $id_specialn
 * @property string $id_sotrudnika
 * @property string $Den_nedeli
 * @property string $Time_priem_1
 * @property string $Time_priem_2
 * @property string $Time_priem_3
 * @property string $Time_priem_4
 * @property string $Time_priem_5
 * @property string $Time_priem_6
 * @property string $Time_priem_7
 * @property string $Time_priem_8
 * @property string $Time_priem_9
 * @property string $Time_priem_10
 *
 * @property Sotrudniki $idSotrudnika
 * @property Tablzapisinapriem[] $tablzapisinapriems
 */
class SetkaPriema extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'Setka_priema';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['Data_priema', 'id_specialn', 'id_sotrudnika', 'Den_nedeli', 'Time_priem_1', 'Time_priem_2', 'Time_priem_3', 'Time_priem_4', 'Time_priem_5', 'Time_priem_6', 'Time_priem_7', 'Time_priem_8', 'Time_priem_9', 'Time_priem_10'], 'required'],
            [['Data_priema', 'Time_priem_1', 'Time_priem_2', 'Time_priem_3', 'Time_priem_4', 'Time_priem_5', 'Time_priem_6', 'Time_priem_7', 'Time_priem_8', 'Time_priem_9', 'Time_priem_10'], 'safe'],
            [['id_specialn', 'id_sotrudnika'], 'integer'],
          //  [['Den_nedeli'], 'string'],
            [['id_sotrudnika'], 'exist', 'skipOnError' => true, 'targetClass' => Sotrudniki::className(), 'targetAttribute' => ['id_sotrudnika' => 'id_sotr']],
        ];
    }
    
    public function beforeValidate() {
        if(empty($this->Den_nedeli)){
            $this->Den_nedeli ='f';
        }
        $this->id_patient =0;
        return parent::beforeValidate();
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'Data_priema' => 'Дата',
            'id_specialn' => 'Id Specialn',
            'id_sotrudnika' => 'Id Sotrudnika',
            'Den_nedeli' => 'Den Nedeli',
            'Time_priem_1' => '9:00-9:30',
            'Time_priem_2' => '9:30-10:00',
            'Time_priem_3' => '10:00-10:30',
            'Time_priem_4' => '10:30-11:00',
            'Time_priem_5' => '11:00-11:30',
            'Time_priem_6' => '11:30-12:00',
            'Time_priem_7' => '13:00-13:30',
            'Time_priem_8' => '13:30-14:00',
            'Time_priem_9' => '14:00-14:30',
            'Time_priem_10' => '14:30-15:00',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdSotrudnika()
    {
        return $this->hasOne(Sotrudniki::className(), ['id_sotr' => 'id_sotrudnika']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTablzapisinapriems()
    {
        return $this->hasOne
                (Tablzapisinapriem::className(), ['id_specialn' => 'id_specialn']);
    }
}
