<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "Type_proc_lech".
 *
 * @property integer $id
 * @property string $name_type_lech
 */
class TypeProcLech extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'Type_proc_lech';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name_type_lech'], 'required'],
            [['name_type_lech'], 'string'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name_type_lech' => 'Типы лечения',
        ];
    }
    public function getTypeProcLechName()       
   {
    return $this-> id->name_type_lech;  
   }
   
    public static function getListdropdown() {
        
        return \yii\helpers\ArrayHelper::map(self::find()->all(), 'id', 'name_type_lech');   
    }
   
}
