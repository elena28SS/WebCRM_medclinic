<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\CartPatient;

/**
 * CartPatientSearch represents the model behind the search form about `app\models\CartPatient`.
 */
class CartPatientSearch extends CartPatient
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id_patient', 'id_sotr'], 'integer'],
            [['Complains', 'Lecheniye', 'Anamnesis_morbi', 'Anamnesis_vitae', 'Lek_allergye', 'kod_Mkb10', 'Name_Diagnozis', 'Epicrysis'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = CartPatient::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id_patient' => $this->id_patient,
            'id_sotr' => $this->id_sotr,
        ]);

        $query->andFilterWhere(['like', 'Complains', $this->Complains])
            ->andFilterWhere(['like', 'Lecheniye', $this->Lecheniye])
            ->andFilterWhere(['like', 'Anamnesis_morbi', $this->Anamnesis_morbi])
            ->andFilterWhere(['like', 'Anamnesis_vitae', $this->Anamnesis_vitae])
            ->andFilterWhere(['like', 'Lek_allergye', $this->Lek_allergye])
            ->andFilterWhere(['like', 'kod_Mkb10', $this->kod_Mkb10])
            ->andFilterWhere(['like', 'Name_Diagnozis', $this->Name_Diagnozis])
            ->andFilterWhere(['like', 'Epicrysis', $this->Epicrysis]);

        return $dataProvider;
    }
}
