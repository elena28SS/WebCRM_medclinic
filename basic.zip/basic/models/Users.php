<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "Users".
 *
 * @property string $id
 * @property integer $status
 * @property string $login
 * @property string $passvord
 *
 * @property Sotrudn $id0
 */
class Users extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'Users';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['status', 'login', 'passvord'], 'required'],
            [['status'], 'integer'],
            [['login', 'passvord'], 'string', 'max' => 50],
            [['id'], 'exist', 'skipOnError' => true, 'targetClass' => Sotrudn::className(), 'targetAttribute' => ['id' => 'id_sotr']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'status' => Yii::t('app', 'Status'),
            'login' => Yii::t('app', 'Login'),
            'passvord' => Yii::t('app', 'Passvord'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getId0()
    {
        return $this->hasOne(Sotrudn::className(), ['id_sotr' => 'id']);
    }

    /**
     * @inheritdoc
     * @return UsersQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new UsersQuery(get_called_class());
    }
}
