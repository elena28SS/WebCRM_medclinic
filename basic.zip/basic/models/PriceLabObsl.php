<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "Price_lab_obsl".
 *
 * @property string $id_analisa
 * @property integer $ed_iz
 * @property string $Stoimost
 * @property string $valuta
 *
 * @property ListLabObsledov $idAnalisa
 */
class PriceLabObsl extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'Price_lab_obsl';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id_analisa', 'ed_iz', 'Stoimost', 'valuta'], 'required'],
            [['ed_iz'], 'integer'],
            [['Stoimost'], 'number'],
            [['valuta'], 'string'],
            [['id_analisa'], 'string', 'max' => 11],
            [['id_analisa'], 'exist', 'skipOnError' => true, 'targetClass' => ListLabObsledov::className(), 'targetAttribute' => ['id_analisa' => 'id_analiz']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_analisa' => 'Id Analisa',
            'ed_iz' => 'Ed Iz',
            'Stoimost' => 'Stoimost',
            'valuta' => 'Valuta',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdAnalisa()
    {
        return $this->hasOne(ListLabObsledov::className(), ['id_analiz' => 'id_analisa']);
    }
}
