<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "Raspisanie".
 *
 * @property integer $id
 * @property integer $id_spec
 * @property integer $id_sotr
 * @property string $Den_nedeli
 * @property string $Priem_begin
 * @property string $Priem_end
 */
class Raspisanie extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'Raspisanie';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'id_spec', 'id_sotr', 'Den_nedeli', 'Priem_begin', 'Priem_end'], 'required'],
            [['id', 'id_spec', 'id_sotr'], 'integer'],
            [['Den_nedeli'], 'string'],
            [['Priem_begin', 'Priem_end'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'id_spec' => 'Специальность',
            'id_sotr' => 'ФИО врача',
            'Den_nedeli' => 'День недели',
            'Priem_begin' => 'Начало приема',
            'Priem_end' => 'Конец приема',
        ];
    }
     public function getIdSpec()
    {
        return $this->hasOne(Raspisanie::className(), ['id' => 'id_spec']);
    }
    
      public function getid_sotr0()
    {
        return $this->hasOne(Sotrudniki::className(), ['id_sotr' => 'id_sotr']);
    }
     public function getSotrudnikiName()       
   {
    return $this-> id_sotr0->FIO;  
   }
   /**
     * @return \yii\db\ActiveQuery
     */
    public static function getListdropdown() {
        
        return \yii\helpers\ArrayHelper::map(self::find()->all(), 'id_sotr', 'FIO');   
    }
    public function getid_spec0()
    {
        return $this->hasOne(SpecialisationSpr::className(), ['id' => 'id_spec']);
    }
    public function getSpecialisationSprName()       
    {
    return $this->id_spec0->name_special;  
    }
    
}
