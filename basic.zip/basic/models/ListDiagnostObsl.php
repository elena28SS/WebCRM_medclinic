<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "ListDiagnostObsl".
 *
 * @property integer $id
 * @property integer $id_patient
 * @property integer $id_diagnostic
 * @property string $data_diagnostic
 * @property integer $id_sotr
 * @property string $Resultat
 */
class ListDiagnostObsl extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'ListDiagnostObsl';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id_patient', 'id_diagnostic', 'data_diagnostic', 'id_sotr', 'Resultat'], 'required'],
            [['id_patient', 'id_diagnostic', 'id_sotr'], 'integer'],
            [['data_diagnostic'], 'safe'],
            [['Resultat'], 'string', 'max' => 225],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'id_patient' => 'Id пациента',
            'id_diagnostic' => 'Название диагностики',
            'data_diagnostic' => 'Дата проведения',
            'id_sotr' => 'ФИО сотр',
            'Resultat' => 'Результат',
        ];
    }
      
    public function getid_patient0()
    {
        return $this->hasOne(InfoPatients::className(), ['id_patient' => 'id_patient']);
    }
      public function getPatientName()       
   {
    return $this-> id_patient0->FIO;  
   }
    public function getid_diagnostic0()
    {
        return $this->hasOne(DiagnostikaSpr::className(), ['id' => 'id_diagnostic']);
    }
      public function getDiagnostikaSprName()       
   {
    return $this-> id_diagnostic0->name_diagnjstik;  
   }
}
