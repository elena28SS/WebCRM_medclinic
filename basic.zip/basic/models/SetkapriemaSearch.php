<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\SetkaPriema;

/**
 * SetkaPriemaSearch represents the model behind the search form about `app\models\SetkaPriema`.
 */
class SetkaPriemaSearch extends SetkaPriema
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'id_specialn', 'id_sotrudnika'], 'integer'],
            [['Data_priema', 'Den_nedeli', 'Time_priem_1', 'Time_priem_2', 'Time_priem_3', 'Time_priem_4', 'Time_priem_5', 'Time_priem_6', 'Time_priem_7', 'Time_priem_8', 'Time_priem_9', 'Time_priem_10'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = SetkaPriema::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'Data_priema' => $this->Data_priema,
            'id_specialn' => $this->id_specialn,
            'id_sotrudnika' => $this->id_sotrudnika,
            'Time_priem_1' => $this->Time_priem_1,
            'Time_priem_2' => $this->Time_priem_2,
            'Time_priem_3' => $this->Time_priem_3,
            'Time_priem_4' => $this->Time_priem_4,
            'Time_priem_5' => $this->Time_priem_5,
            'Time_priem_6' => $this->Time_priem_6,
            'Time_priem_7' => $this->Time_priem_7,
            'Time_priem_8' => $this->Time_priem_8,
            'Time_priem_9' => $this->Time_priem_9,
            'Time_priem_10' => $this->Time_priem_10,
        ]);

        $query->andFilterWhere(['like', 'Den_nedeli', $this->Den_nedeli]);

        return $dataProvider;
    }
}
