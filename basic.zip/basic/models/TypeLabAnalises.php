<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "Type_lab_analises".
 *
 * @property string $id_type_analises
 * @property integer $name_type_analises
 */
class TypeLabAnalises extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'Type_lab_analises';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'name_type_analises'], 'required'],
            [['name_type_analises'], 'string','max' => 100],
            [['id'], 'integer', 'max' => 11],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name_type_analises' => 'Тип анализа',
        ];
    }
     public static function getListdropdown() {
        
        return \yii\helpers\ArrayHelper::map(self::find()->all(), 'id', 'name_type_analises');
        
    }
}
