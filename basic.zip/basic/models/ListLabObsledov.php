<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "ListLabObsledov".
 *
 * @property integer $id
 * @property integer $id_patient
 * @property integer $id_analiz
 * @property string $data_obsl
 * @property integer $id_sotr
 * @property string $Result
 */
class ListLabObsledov extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'ListLabObsledov';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id_patient', 'id_analiz', 'data_obsl', 'id_sotr', 'Result'], 'required'],
            [['id_patient', 'id_analiz', 'id_sotr'], 'integer'],
            [['data_obsl'], 'safe'],
            [['Result'], 'string', 'max' => 225],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'id_patient' => Yii::t('app', 'Id пациента'),
            'id_analiz' => Yii::t('app', 'Анализ'),
            'data_obsl' => Yii::t('app', 'Дата проведения'),
            'id_sotr' => Yii::t('app', 'ФИО сотр'),
            'Result' => Yii::t('app', 'Результат'),
        ];
    }
     public function getid_patient0()
    {
        return $this->hasOne(InfoPatients::className(), ['id_patient' => 'id_patient']);
    }
      public function getPatientName()       
   {
    return $this-> id_patient0->FIO;  
   }
    public function getidanaliz0()
    {
        return $this->hasOne(LabAnalises::className(), ['id' => 'id_analiz']);
    }
      public function getLabAnalisesName()       
   {
    return $this-> idanaliz0->name_analisa;  
   }
}
