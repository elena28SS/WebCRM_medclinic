<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "tablzapisinapriem".
 *
 * @property integer $id
 * @property string $Data_priema
 * @property string $Vremia_priema
 * @property string $id_sotr
 * @property integer $id_specialn
 * @property integer $id_patient
 * @property string $Telefon_patienta
 * @property string $Diagnosis
 * @property string $Pervichniy
 *
 * @property Sotrudniki $idSotr
 * @property InfoPatients $idPatient
 * @property SetkaPriema $idSpecialn
 */
class Tablzapisinapriem extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'tablzapisinapriem';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['Data_priema','Vremia_priema','id_patient', 'Telefon_patienta', 'Diagnosis', 'Pervichniy'], 'required'],
            [['Data_priema','Vremia_priema','id_specialn','id_sotr'],'safe'],
            [['id_sotr', 'id_specialn', 'id_patient', 'Telefon_patienta'], 'integer'],
            [['Pervichniy'], 'string'],
            [['Diagnosis'], 'string', 'max' => 150],
            [['id_sotr'], 'exist', 'skipOnError' => true, 'targetClass' => Sotrudniki::className(), 'targetAttribute' => ['id_sotr' => 'id_sotr']],
            [['id_patient'], 'exist', 'skipOnError' => true, 'targetClass' => InfoPatients::className(), 'targetAttribute' => ['id_patient' => 'id_patient']],
            [['id_specialn'], 'exist', 'skipOnError' => true, 'targetClass' => SetkaPriema::className(), 'targetAttribute' => ['id_specialn' => 'id_specialn']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'Data_priema' => 'Дата приема',
            'Vremia_priema' => 'Время приема',
            'id_sotr' => 'ФИО сотр',
            'id_specialn' => 'Специализация',
            'id_patient' => 'Id пациента',
            'Telefon_patienta' => 'Телефон пациента',
            'Diagnosis' => 'Диагноз',
            'Pervichniy' => ' Первичный',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdSotr()
    {
        return $this->hasOne(Sotrudniki::className(), ['id_sotr' => 'id_sotr']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdPatient()
    {
        return $this->hasOne(InfoPatients::className(), ['id_patient' => 'id_patient']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdSpecialn()
    {
        return $this->hasOne(SetkaPriema::className(), ['id_specialn' => 'id_specialn']);
    }
    
    /**
     * @return \yii\db\ActiveQuery
     */
    
     public function getid_sotr0()
    {
        return $this->hasOne(Sotrudniki::className(), ['id_sotr' => 'id_sotr']);
    }
     public function getSotrudnikiName()       
   {
    return $this-> id_sotr0->FIO;  
   }
   /**
     * @return \yii\db\ActiveQuery
     */
   
    public function getid_specialn0()
    {
        return $this->hasOne(SpecialisationSpr::className(), ['id' => 'id_specialn']);
    }
    public function getSpecialisationSprName()       
    {
    return $this->id_specialn0->name_special;  
    }
}
