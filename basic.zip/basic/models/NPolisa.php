<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "N_polisa".
 *
 * @property string $N_polisa
 * @property string $id_comp
 * @property string $Vid_str
 */
class NPolisa extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'N_polisa';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id_comp', 'Vid_str'], 'required'],
            [['id_comp'], 'integer'],
            [['Vid_str'], 'string'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'N_polisa' => Yii::t('app', 'N Polisa'),
            'id_comp' => Yii::t('app', 'Id Comp'),
            'Vid_str' => Yii::t('app', 'Vid Str'),
        ];
    }
}
