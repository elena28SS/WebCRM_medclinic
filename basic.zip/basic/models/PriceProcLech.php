<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "Price_proc_lech".
 *
 * @property integer $id_proc_lech
 * @property integer $ed_iz
 * @property string $stoimost
 * @property string $valuta
 *
 * @property ListLechProced $idProcLech
 * @property ProcedLechSpr $procedLechSpr
 */
class PriceProcLech extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'Price_proc_lech';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id_proc_lech', 'ed_iz', 'stoimost', 'valuta'], 'required'],
            [['id_proc_lech', 'ed_iz'], 'integer'],
            [['stoimost'], 'number'],
            [['valuta'], 'string'],
            [['id_proc_lech'], 'exist', 'skipOnError' => true, 'targetClass' => ListLechProced::className(), 'targetAttribute' => ['id_proc_lech' => 'id_proced_lech']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_proc_lech' => 'Id Proc Lech',
            'ed_iz' => 'Ed Iz',
            'stoimost' => 'Stoimost',
            'valuta' => 'Valuta',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdProcLech()
    {
        return $this->hasOne(ListLechProced::className(), ['id_proced_lech' => 'id_proc_lech']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getProcedLechSpr()
    {
        return $this->hasOne(ProcedLechSpr::className(), ['id_proced_lech' => 'id_proc_lech']);
    }
}
