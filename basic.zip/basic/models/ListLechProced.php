<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "ListLechProced".
 *
 * @property integer $id
 * @property integer $id_patient
 * @property integer $id_proced_lech
 * @property integer $ed_izm
 * @property string $data_proc
 * @property integer $cours_kol
 */
class ListLechProced extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'ListLechProced';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id_patient', 'id_proced_lech', 'ed_izm', 'data_proc', 'cours_kol'], 'required'],
            [['id_patient', 'id_proced_lech', 'ed_izm', 'cours_kol'], 'integer'],
            [['data_proc'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'id_patient' => Yii::t('app', 'Id пациента'),
            'id_proced_lech' => Yii::t('app', 'Название лечения'),
            'ed_izm' => Yii::t('app', 'Ед изм'),
            'data_proc' => Yii::t('app', 'Дата проведения'),
            'cours_kol' => Yii::t('app', 'Кол-во на курс'),
        ];
    }
     public function getid_patient0()
    {
        return $this->hasOne(InfoPatients::className(), ['id_patient' => 'id_patient']);
    }
      public function getPatientName()       
   {
    return $this-> id_patient0->FIO;  
   }
    public function getid_procedlech0()
    {
        return $this->hasOne(ProcedLechSpr::className(), ['id' => 'id_proced_lech']);
    }
      public function getProcedLechSprName()       
   {
    return $this-> id_procedlech0->name_procedure;  
   }
}
