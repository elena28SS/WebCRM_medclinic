<?php

namespace app\models;

use Yii;



/**
 * This is the model class for table "Lab_analises".
 *
 * @property integer $id
 * @property string $name_analisa
 * @property integer $id_type_analises
 *
 * @property TypeLabAnalises $idTypeAnalises
 */
class LabAnalises extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'Lab_analises';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name_analisa', 'id_type_analises'], 'required'],
            [['name_analisa'], 'string'],
            [['id_type_analises'], 'integer'],
            [['id_type_analises'], 'exist', 'skipOnError' => true, 'targetClass' => TypeLabAnalises::className(), 'targetAttribute' => ['id_type_analises' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name_analisa' => 'Название анализа',
            'id_type_analises' => 'Тип анализов',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getType0()
    {
        return $this->hasOne(TypeLabAnalises::className(),['id' => 'id_type_analises']);
    }
   public function getTypeLabAnalisesName()       
   {
   return $this->type0 ->name_type_analises;  
   }  
   public static function getListdropdown() {
        
        return \yii\helpers\ArrayHelper::map(self::find()->all(), 'id', 'name_analisa');   
    }  
}
