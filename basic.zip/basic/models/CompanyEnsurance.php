<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "Company_Ensurance".
 *
 * @property string $id_com
 * @property string $Name_company
 *
 * @property NPolisa $nPolisa
 */
class CompanyEnsurance extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'Company_Ensurance';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['Name_company'], 'required'],
            [['Name_company'], 'string'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_com' => Yii::t('app', 'Id Com'),
            'Name_company' => Yii::t('app', 'Название ТФОМС'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getNPolisa()
    {
        return $this->hasOne(NPolisa::className(), ['id_comp' => 'id_com']);
    }
}
