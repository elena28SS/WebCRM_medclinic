<?php
 namespace app\components;
use yii\base\Widget;
use yii\app\components;

class HalWidget extends Widget{
public function run()
{
 return '<h2>Hallo!</h2>';
}

}