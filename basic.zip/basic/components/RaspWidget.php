<?php
 namespace app\components;
use yii\base\Widget;
use yii\app\components;

class RaspWidget extends Widget{
public function run()
{
 return $this ->render ('Rasp1');
}

}