
 <p> <h2 class="sub-header">Расписание</h2></p>
                            <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                <tr>
                                 <th>День нед.</th>
                                    <th>Часы приема</th>
                                   </tr>
                                </thead>
                              <tbody>
                                <tr>
                                <td>ПН</td>
                                 <td>10:00-12:00</td>
                              </tr>	
                             <tr>
                                <td>ВТ</td>
                                 <td>12:00 - 15:00</td>
                              </tr>	
<tr>
                                <td>СР</td>
                                 <td>17:00 - 20:00</td>
                              </tr>	
<tr>
                                <td>ЧТ</td>
                                 <td>12:00 - 15:00</td>
                              </tr>	
<tr>
                                <td>ПТ</td>
                                 <td>08:00 - 11:00</td>
                              </tr>	
<tr>
                                <td>СБ</td>
                                 <td> нет приема</td>
                              </tr>								  
                              </tbody>				 
                            </table>
