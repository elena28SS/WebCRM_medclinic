<?
 <p> <h2 class="sub-header">Расписание</h2></p>
                            <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                <tr>
                                 <th>День недели</th>
                                    <th>Часы приема</th>
                                   </tr>
                                </thead>
                              <tbody>
                                <tr>
                                <td>ПН</td>
                                 <td>10:00</td>
                              </tr>			
                              </tbody>				 
                            </table>
?>