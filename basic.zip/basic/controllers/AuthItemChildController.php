<?php

namespace app\controllers;

class AuthItemChildController extends \yii\web\Controller
{
    public function actionIndex()
    {
        return $this->render('index');
    }

}
