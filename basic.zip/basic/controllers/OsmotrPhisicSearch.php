<?php

namespace app\controllers;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\OsmotrPhisic;

/**
 * OsmotrPhisicSearch represents the model behind the search form about `app\models\OsmotrPhisic`.
 */
class OsmotrPhisicSearch extends OsmotrPhisic
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id_patient', 'Id_sotrudn', 'heart_rate'], 'integer'],
            [['date_osmotra', 'Respiratory_system', 'Cardiovascular_system', 'Gastrointestinal_tract', 'Urogenitale_system', 'Nervously_psychic_sphere', 'Auscultatia_Chest', 'Palpaciya_lymph_uzl', 'arterialAD'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = OsmotrPhisic::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id_patient' => $this->id_patient,
            'Id_sotrudn' => $this->Id_sotrudn,
            'date_osmotra' => $this->date_osmotra,
            'heart_rate' => $this->heart_rate,
        ]);

        $query->andFilterWhere(['like', 'Respiratory_system', $this->Respiratory_system])
            ->andFilterWhere(['like', 'Cardiovascular_system', $this->Cardiovascular_system])
            ->andFilterWhere(['like', 'Gastrointestinal_tract', $this->Gastrointestinal_tract])
            ->andFilterWhere(['like', 'Urogenitale_system', $this->Urogenitale_system])
            ->andFilterWhere(['like', 'Nervously_psychic_sphere', $this->Nervously_psychic_sphere])
            ->andFilterWhere(['like', 'Auscultatia_Chest', $this->Auscultatia_Chest])
            ->andFilterWhere(['like', 'Palpaciya_lymph_uzl', $this->Palpaciya_lymph_uzl])
            ->andFilterWhere(['like', 'arterialAD', $this->arterialAD]);

        return $dataProvider;
    }
}
