<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
--> 
<?php

namespace app\controllers;

use Yii;
use app\models\Sotrudniki;
use yii\data\ActiveDataProvider;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * SotrudnController implements the CRUD actions for Sotrudn model.
 */
class SotrudnikiController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }
    public $layout = 'page_sotrudnika_model.php';
    /**
     * Lists all Sotrudn models.
     * @return mixed
     * put your code here
     */
}     
      
   