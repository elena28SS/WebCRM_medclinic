<?php

namespace app\controllers;

use Yii;
use app\models\SetkaPriema;
use app\models\SetkaPriemaSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\data\ActiveDataProvider;

/**
 * SetkaPriemaController implements the CRUD actions for SetkaPriema model.
 */
class SetkaPriemaController extends Controller {

    /**
     * @inheritdoc
     */
    public function behaviors() {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all SetkaPriema models.
     * @return mixed
     */
    public function actionIndex($date = 'now') {

        $sysDate = new \DateTime($date, new \DateTimeZone('Europe/Moscow'));
        $cur_month = $sysDate->format('Y-m');


        $cur_time = strtotime($sysDate->format('Y-m-01'));
        $week_start = strtotime("last Monday", mktime(0, 0, 0, date("n", $cur_time), date("j", $cur_time), date("Y", $cur_time)));

        $boundle = [];



        for ($i = 0; $i < 6; $i++) { // Недели месяца
            $bweek = [];
            $lastweek = false;
            for ($j = 0; $j < 7; $j++) { // Дни недели
                $morning = $week_start + $j * 24 * 3600 + $i * 7 * 24 * 3600;

                if ($cur_month != date('Y-m', $morning)) { // этот день не наш месяц
                    if ($i !== 0) {
                        $lastweek = true;
                    }
                    $bweek[$morning] = false;
                    continue;
                }

                if ($rq = SetkaPriema::find()->where(['LIKE', 'Data_priema', date('Y-m-d', $morning)])->one())
                    $bweek[$morning] = $rq;
                else
                    $bweek[$morning] = true;
            }
            $boundle[] = $bweek;
            if ($lastweek)
                break;
        }

       


        return $this->render('index', [
                    'boundle' => $boundle,                  
        ]);
    }

    /**
     * Displays a single SetkaPriema model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id) {
        return $this->render('view', [
                    'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new SetkaPriema model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate() {
        $model = new SetkaPriema();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['index']);
        } else {
                //var_dump($model->errors); return'';
            return $this->render('create', [
                        'model' => $model,
            ]);
        }
    }

    /**
     * Updates an existing SetkaPriema model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id) {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['index', ]);
        } else {
            return $this->render('update', [
                        'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing SetkaPriema model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id) {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the SetkaPriema model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return SetkaPriema the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id) {
        if (($model = SetkaPriema::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

}
