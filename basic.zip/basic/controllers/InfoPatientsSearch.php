<?php

namespace app\controllers;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\InfoPatients;

/**
 * InfoPatientsSearch represents the model behind the search form about `app\models\InfoPatients`.
 */
class InfoPatientsSearch extends InfoPatients
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['Data_create', 'gender', 'FIO', 'Birhtday', 'Adress', 'City', 'street', 'name_company_ens', 'N_serya_Pasport'], 'safe'],
            [['id_sotr_create', 'id_patient', 'N_polisa', 'SNILS'], 'integer'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = InfoPatients::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'Data_create' => $this->Data_create,
            'id_sotr_create' => $this->id_sotr_create,
            'id_patient' => $this->id_patient,
            'Birhtday' => $this->Birhtday,
            'N_polisa' => $this->N_polisa,
            'SNILS' => $this->SNILS,
        ]);

        $query->andFilterWhere(['like', 'gender', $this->gender])
            ->andFilterWhere(['like', 'FIO', $this->FIO])
            ->andFilterWhere(['like', 'Adress', $this->Adress])
            ->andFilterWhere(['like', 'City', $this->City])
            ->andFilterWhere(['like', 'street', $this->street])
            ->andFilterWhere(['like', 'name_company_ens', $this->name_company_ens])
            ->andFilterWhere(['like', 'N_serya_Pasport', $this->N_serya_Pasport]);

        return $dataProvider;
    }
}
